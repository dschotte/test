package com.proximus.cds.oracle12;

import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class Parameter {
	
	protected static final Pattern PLACEHOLDER = Pattern.compile("(?<!')(:[\\w]*)(?!')"); // :name
	
	private String name;
	private String valueAsString;
	
	protected Parameter(String name) {
		this.name = name;
	}

	protected String getName() {
		return name;
	}

	protected String getValueAsString() {
		return StringUtils.defaultString(valueAsString, "NULL");
	}
	
	protected void setValue(Object x) {
		if (x != null) {
			valueAsString = x.toString();
		} else {
			valueAsString = null;
		}
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(name).toHashCode();
	}

	@Override
	public boolean equals(Object other) {
		if (other instanceof Parameter == false) {
			return false;
		}
		return new EqualsBuilder().append(this.name, ((Parameter) other).name).isEquals();
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
	
}
