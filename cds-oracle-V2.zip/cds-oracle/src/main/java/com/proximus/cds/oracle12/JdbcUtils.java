package com.proximus.cds.oracle12;

import java.sql.Blob;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import oracle.xdb.XMLType;

public class JdbcUtils {
	
    private static final Logger logger = LoggerFactory.getLogger(JdbcUtils.class);

    /**
     * Performs a rollback on the given <code>Connection</code> and then closes it, ignoring any <code>SQLException</code> that occurs. This is typically used in finally blocks.
     * 
     * @param conn the connection; may be null
     */
	public static void closeQuietly(Connection conn) {
		try {
			if (conn != null) {
				try {
					conn.rollback();
				} catch (SQLException e) {
					logger.error("Could not rollback changes and release locks held by connection", e);
				}
				conn.close();				
			}
		} catch (SQLException e) {
			logger.error("Could not close connection", e);
		}
	}
	
	/**
	 * Releases the given <code>SimpleCall</code> object's resources, ignoring any <code>SQLException</code> that occurs. This is typically used in finally blocks.
	 * 
	 * @param c the object; may be null
	 */
    public static void closeQuietly(SimpleCall c) {
        try {
            if (c != null) {
            	c.close();
            }
        } catch (SQLException e) {
			logger.error("Could not close", e);
		}
    }    

	/**
	 * Releases the given <code>SimpleResult</code> object's resources, ignoring any <code>SQLException</code> that occurs. This is typically used in finally blocks.
	 * 
	 * @param r the object; may be null
	 */
    public static void closeQuietly(SimpleResult r) {
        try {
            if (r != null) {
            	r.close();
            }
        } catch (SQLException e) {
			logger.error("Could not close", e);
		}
    }    
    
    /**
     * Frees the given <code>Blob</code> object and releases the resources that it holds, ignoring any <code>SQLException</code> that occurs. This is typically used in finally blocks.
     * 
     * @param blob the object; may be null
     */
	protected static void freeQuietly(Blob blob) {
		try {
			if (blob != null) {
				blob.free();
			}
		} catch (SQLException e) {
			logger.error("Could not free object", e);
		}
	}    

    /**
     * Frees the given <code>Clob</code> object and releases the resources that it holds, ignoring any <code>SQLException</code> that occurs. This is typically used in finally blocks.
     * 
     * @param clob the object; may be null
     */
	protected static void freeQuietly(Clob clob) {
		try {
			if (clob != null) {
				clob.free();
			}
		} catch (SQLException e) {
			logger.error("Could not free object", e);
		}
	}    

    /**
     * Frees the given <code>XMLType</code> object and releases the resources that it holds, ignoring any <code>SQLException</code> that occurs. This is typically used in finally blocks.
     * 
     * @param XML the object; may be null
     */
	protected static void freeQuietly(XMLType XML) {
		try {
			if (XML != null) {
				XML.free();
			}
		} catch (SQLException e) {
			logger.error("Could not free object", e);
		}
	}    
    
}
