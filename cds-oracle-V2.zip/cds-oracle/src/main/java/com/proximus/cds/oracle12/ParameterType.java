package com.proximus.cds.oracle12;

public enum ParameterType {

	BYTES(java.sql.Types.BINARY),
	BLOB(java.sql.Types.BLOB),
	CLOB(java.sql.Types.CLOB),
	DOUBLE(java.sql.Types.DOUBLE),
	INT(java.sql.Types.INTEGER),
	LOCAL_DATE(java.sql.Types.DATE),
	LOCAL_DATE_TIME(java.sql.Types.TIMESTAMP),
	LOCAL_TIME(java.sql.Types.TIME),
	LONG(java.sql.Types.BIGINT),
	STRING(java.sql.Types.VARCHAR),
	UUID(java.sql.Types.BINARY),
	XML_TYPE(oracle.jdbc.OracleTypes.OPAQUE),

	CURSOR(oracle.jdbc.OracleTypes.CURSOR);
	
	private final int code;
	
	private ParameterType(int code) {
		this.code = code;
	}
	
	public int getCode() {
		return code;
	}

}
