package com.proximus.cds.oracle12;

import java.io.ByteArrayInputStream;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import oracle.jdbc.OracleConnection;
import oracle.xdb.XMLType;

public class SimpleCall implements AutoCloseable {

    private static final Logger logger = LoggerFactory.getLogger(SimpleCall.class);
	
	private List<Parameter> parameterList = new ArrayList<Parameter>();
	
	private String jdbcSql;
	
	private CallableStatement cs;
	
	private List<XMLType> XMLList = new ArrayList<XMLType>();
	
	/**
	 * Creates a <code>SimpleCall</code> object for calling database stored procedures. The <code>SimpleCall</code> object provides methods for setting up its IN and OUT parameters, and methods for executing the call to a stored procedure.
	 * 
	 * @param conn a connection (session) with a specific database
	 * @param sql an SQL statement that may contain one or more <code>:name</code> parameter placeholders. This statement calls a stored procedure using JDBC call escape syntax
	 */
	public SimpleCall(Connection conn, String sql) throws SQLException {
		Matcher matcher = Parameter.PLACEHOLDER.matcher(sql);
		while (matcher.find()) {
			parameterList.add(new Parameter(matcher.group().substring(1))); // :name as name
		}
		jdbcSql = sql.replaceAll(Parameter.PLACEHOLDER.pattern(), "?"); // :name by ?
		cs = conn.prepareCall(jdbcSql);
	}

	/**
	 * Retrieves the value of a <code>ParameterType.BLOB</code> parameter as an array of <code>byte</code> values.
	 * 
	 * @param parameterName the name of the parameter
	 * 
	 * @return the parameter value. If the value is SQL NULL, the result is null
	 * 
	 * @throws SQLException
	 */
	public byte[] getBlobAsBytes(String parameterName) throws SQLException {
	   	Blob blob = null;
		try {
			blob = cs.getBlob(getParameterIndex(parameterName));
			if (cs.wasNull()) {
				return null;
			}
			return blob.getBytes(1, (int) blob.length());
		} finally {
			JdbcUtils.freeQuietly(blob);
		}		
	}

	/**
	 * Retrieves the value of a <code>ParameterType.BYTES</code> parameter as an array of <code>byte</code> values.
	 * 
	 * @param parameterName the name of the parameter
	 * 
	 * @return the parameter value. If the value is SQL NULL, the result is null
	 * 
	 * @throws SQLException
	 */
	public byte[] getBytes(String parameterName) throws SQLException {
		byte[] bytes = cs.getBytes(getParameterIndex(parameterName));
		if (cs.wasNull()) {
			return null;
		}
		return bytes;
	}

	/**
	 * Retrieves the value of a <code>ParameterType.CLOB</code> parameter as a <code>String</code>.
	 * 
	 * @param parameterName the name of the parameter
	 * 
	 * @return the parameter value. If the value is SQL NULL, the result is null
	 * 
	 * @throws SQLException
	 */
	public String getClobAsString(String parameterName) throws SQLException {
		Clob clob = null;
		try {
			clob = cs.getClob(getParameterIndex(parameterName));			
			if (cs.wasNull()) {
				return null;
			}
			return clob.getSubString(1, (int) clob.length());
		} finally {
			JdbcUtils.freeQuietly(clob);
		}		
	}	

	/**
	 * Retrieves the value of a <code>ParameterType.DOUBLE</code> parameter as a <code>double</code>.
	 * 
	 * @param parameterName the name of the parameter
	 * 
	 * @return the parameter value. If the value is SQL NULL, the result is 0
	 * 
	 * @throws SQLException
	 */
	public double getDouble(String parameterName) throws SQLException {
		return cs.getDouble(getParameterIndex(parameterName));
	}

	/**
	 * Retrieves the value of a <code>ParameterType.INT</code> parameter as a <code>int</code>.
	 * 
	 * @param parameterName the name of the parameter
	 * 
	 * @return the parameter value. If the value is SQL NULL, the result is 0
	 * 
	 * @throws SQLException
	 */
	public int getInt(String parameterName) throws SQLException {
		return cs.getInt(getParameterIndex(parameterName));
	}

	/**
	 * Retrieves the value of a <code>ParameterType.LOCAL_DATE</code> parameter as a <code>LocalDate</code>.
	 * 
	 * @param parameterName the name of the parameter
	 * 
	 * @return the parameter value. If the value is SQL NULL, the result is null
	 * 
	 * @throws SQLException
	 */
	public LocalDate getLocalDate(String parameterName) throws SQLException {
		java.sql.Date date = cs.getDate(getParameterIndex(parameterName));
		if (cs.wasNull()) {
			return null;
		}
		return date.toLocalDate();
	}

	/**
	 * Retrieves the value of a <code>ParameterType.LOCAL_DATE_TIME</code> parameter as a <code>LocalDateTime</code>.
	 * 
	 * @param parameterName the name of the parameter
	 * 
	 * @return the parameter value. If the value is SQL NULL, the result is null
	 * 
	 * @throws SQLException
	 */
	public LocalDateTime getLocalDateTime(String parameterName) throws SQLException {
		java.sql.Timestamp timestamp = cs.getTimestamp(getParameterIndex(parameterName));
		if (cs.wasNull()) {
			return null;
		}
		return timestamp.toLocalDateTime();
	}	

	/**
	 * Retrieves the value of a <code>ParameterType.LOCAL_TIME</code> parameter as a <code>LocalTime</code>.
	 * 
	 * @param parameterName the name of the parameter
	 * 
	 * @return the parameter value. If the value is SQL NULL, the result is null
	 * 
	 * @throws SQLException
	 */
	public LocalTime getLocalTime(String parameterName) throws SQLException {
		java.sql.Time time = cs.getTime(getParameterIndex(parameterName));
		if (cs.wasNull()) {
			return null;
		}
		return time.toLocalTime();
	}

	/**
	 * Retrieves the value of a <code>ParameterType.LONG</code> parameter as a <code>long</code>.
	 * 
	 * @param parameterName the name of the parameter
	 * 
	 * @return the parameter value. If the value is SQL NULL, the result is 0
	 * 
	 * @throws SQLException
	 */	
	public long getLong(String parameterName) throws SQLException {
		return cs.getLong(getParameterIndex(parameterName));
	}	

	/**
	 * Retrieves the value of a <code>ParameterType.STRING</code> parameter as a <code>String</code>.
	 * 
	 * @param parameterName the name of the parameter
	 * 
	 * @return the parameter value. If the value is SQL NULL, the result is null
	 * 
	 * @throws SQLException
	 */
	public String getString(String parameterName) throws SQLException {
		return cs.getString(getParameterIndex(parameterName));
	}

	/**
	 * Retrieves the value of a <code>ParameterType.UUID</code> parameter as a <code>UUID</code>.
	 * 
	 * @param parameterName the name of the parameter
	 * 
	 * @return the parameter value. If the value is SQL NULL, the result is null
	 * 
	 * @throws SQLException
	 */
	public UUID getUUID(String parameterName) throws SQLException {
		byte[] bytes = cs.getBytes(getParameterIndex(parameterName));
		if (cs.wasNull()) {
			return null;
		}
		return UUIDUtils.toUUID(bytes);
	}

	/**
	 * Retrieves the value of a <code>ParameterType.XML_TYPE</code> parameter as a <code>String</code>.
	 * 
	 * @param parameterName the name of the parameter
	 * 
	 * @return the parameter value. If the value is SQL NULL, the result is null
	 * 
	 * @throws SQLException
	 */
	public String getXMLTypeAsString(String parameterName) throws SQLException {
		XMLType XML = null;	
		try {
			XML = (XMLType) cs.getObject(getParameterIndex(parameterName)); 
			if (cs.wasNull()) {
				return null;
			}
			return XML.getString();
		} finally {
			JdbcUtils.freeQuietly(XML);
		}
	}

	/**
	 * Sets the designated parameter to the given array of <code>byte</code> values.
	 * 
	 * @param parameterName the name of the parameter
	 * @param bytes the parameter value
	 * 
	 * @throws SQLException
	 */
	public void setBytes(String parameterName, byte[] bytes) throws SQLException {
		if (bytes == null) {
			cs.setNull(setParameterValue(parameterName, bytes), ParameterType.BYTES.getCode());	
		} else {
			cs.setBytes(setParameterValue(parameterName, bytes), bytes);
		}
	}

	/**
	 * Sets the designated parameter to the given <code>double</code> value.
	 * 
	 * @param parameterName the name of the parameter
	 * @param x the parameter value
	 * 
	 * @throws SQLException
	 */
	public void setDouble(String parameterName, double x) throws SQLException {
		cs.setDouble(setParameterValue(parameterName, x), x);
	}	

	/**
	 * Sets the designated parameter to the given <code>int</code> value.
	 * 
	 * @param parameterName the name of the parameter
	 * @param x the parameter value
	 * 
	 * @throws SQLException
	 */
	public void setInt(String parameterName, int x) throws SQLException {
		cs.setInt(setParameterValue(parameterName, x), x);
	}	

	/**
	 * Sets the designated parameter to the given <code>LocalDate</code> value.
	 * 
	 * @param parameterName the name of the parameter
	 * @param localDate the parameter value
	 * 
	 * @throws SQLException
	 */
	public void setLocalDate(String parameterName, LocalDate localDate) throws SQLException {
		if (localDate == null) {
			cs.setNull(setParameterValue(parameterName, localDate), ParameterType.LOCAL_DATE.getCode());
		} else {
			cs.setDate(setParameterValue(parameterName, localDate), java.sql.Date.valueOf(localDate));			
		}
	}		

	/**
	 * Sets the designated parameter to the given <code>LocalDateTime</code> value.
	 * 
	 * @param parameterName the name of the parameter
	 * @param localDateTime the parameter value
	 * 
	 * @throws SQLException
	 */
	public void setLocalDateTime(String parameterName, LocalDateTime localDateTime) throws SQLException {
		if (localDateTime == null) {
			cs.setNull(setParameterValue(parameterName, localDateTime), ParameterType.LOCAL_DATE_TIME.getCode());
		} else {
			cs.setTimestamp(setParameterValue(parameterName, localDateTime), java.sql.Timestamp.valueOf(localDateTime));
		}
	}		

	/**
	 * Sets the designated parameter to the given <code>LocalTime</code> value.
	 * 
	 * @param parameterName the name of the parameter
	 * @param localTime the parameter value
	 * 
	 * @throws SQLException
	 */
	public void setLocalTime(String parameterName, LocalTime localTime) throws SQLException {
		if (localTime == null) {
			cs.setNull(setParameterValue(parameterName, localTime), ParameterType.LOCAL_TIME.getCode());
		} else {
			cs.setTime(setParameterValue(parameterName, localTime), java.sql.Time.valueOf(localTime));			
		}
	}		

	/**
	 * Sets the designated parameter to the given <code>long</code> value.
	 * 
	 * @param parameterName the name of the parameter
	 * @param x the parameter value
	 * 
	 * @throws SQLException
	 */
	public void setLong(String parameterName, long x) throws SQLException {
		cs.setLong(setParameterValue(parameterName, x), x);
	}

	/**
	 * Sets the designated parameter to the given <code>String</code> value.
	 * 
	 * @param parameterName the name of the parameter
	 * @param str the parameter value
	 * 
	 * @throws SQLException
	 */
	public void setString(String parameterName, String str) throws SQLException {
		cs.setString(setParameterValue(parameterName, str), str);
	}

	/**
	 * Sets the designated parameter to the given <code>UUID</code> value.
	 * 
	 * @param parameterName the name of the parameter
	 * @param uuid the parameter value
	 * 
	 * @throws SQLException
	 */
	public void setUUID(String parameterName, UUID uuid) throws SQLException {
		if (uuid == null) {
			cs.setNull(setParameterValue(parameterName, uuid), ParameterType.UUID.getCode());
		} else {
			cs.setBytes(setParameterValue(parameterName, uuid), UUIDUtils.toBytes(uuid));
		}
	}

	/**
	 * Sets the designated <code>ParameterType.XML_TYPE</code> parameter to the given <code>String</code> value.
	 * 
	 * @param parameterName the name of the parameter
	 * @param xml a <code>String</code> that contains the xml to set the parameter value to
	 * 
	 * @throws SQLException
	 */
	public void setXMLType(String parameterName, String xml) throws SQLException {
		if (xml == null) {
			cs.setNull(setParameterValue(parameterName, xml), ParameterType.XML_TYPE.getCode());
		} else {
			XMLType XML = XMLType.createXML(cs.getConnection().unwrap(OracleConnection.class), new ByteArrayInputStream(xml.getBytes())); // unwrap because a proxy connection given by a connection pooler does not expose oracle methods
			cs.setObject(setParameterValue(parameterName, xml), XML);
			XMLList.add(XML);
		}		
	}

	/**
	 * Registers the OUT parameter named <code>parameterName</code> to the type <code>parameterType</code>. All OUT parameters must be registered before the SQL statement in this <code>SimpleCall</code> object is executed.
	 * 
	 * @param parameterName the name of the parameter
	 * @param parameterType the JDBC type code defined by <code>ParameterType</code>
	 * 
	 * @throws SQLException
	 */
	public void registerOutParameter(String parameterName, ParameterType parameterType) throws SQLException {
		cs.registerOutParameter(setParameterValue(parameterName, "#"), parameterType.getCode()); // dummy value for logging of OUT parameter
	}

	/**
	 * Gives the JDBC driver a hint as to the number of rows that should be fetched with each database roundtrip. If the value specified is zero, then the hint is ignored. The default value is zero.
	 * 
	 * @param rows the number of rows to fetch
	 * 
	 * @throws SQLException
	 */
	public void setFetchSize(int rows) throws SQLException {
		cs.setFetchSize(rows);
	}

	/**
	 * Executes the SQL statement in this <code>SimpleCall</code> object.
	 * 
	 * @throws SQLException
	 */
	public void execute() throws SQLException {
		logger.debug("EXECUTE {}", parsedSql());
		cs.execute();
	}
	
	/**
	 * Retrieves the result set referenced by a <code>ParameterType.XML_TYPE</code> parameter as a <code>SimpleResult</code>.
	 * 
	 * @param parameterName the name of the parameter
	 * 
	 * @return a <code>SimpleResult</code> object that contains the result set; never null
	 * 
	 * @throws SQLException
	 */
	public SimpleResult getCursor(String parameterName) throws SQLException {
		return new SimpleResult((ResultSet) cs.getObject(getParameterIndex(parameterName)));
	}

	/**
	 * Adds a set of parameters to this <code>SimpleCall</code> object's batch of commands.
	 * 
	 * @throws SQLException
	 */
	public void addBatch() throws SQLException {
		logger.debug("ADD BATCH {}", parsedSql());
		cs.addBatch();
	}
	
	/**
	 * Submits a batch of commands to the database for execution.
	 * 
	 * @throws SQLException
	 */
	public void executeBatch() throws SQLException {
		logger.debug("EXECUTE BATCH");
		cs.executeBatch();
	}
	
	/**
	 * Releases this <code>SimpleCall</code> object's resources. It is good practice to release resources as soon as you are finished with them.
	 * 
	 * @throws SQLException
	 */
	public void close() throws SQLException {
		for (XMLType XML : XMLList) {
			XML.free();
		}
		cs.close();
	}

	/**
	 * Finds the index of a parameter.
	 * 
	 * @param parameterName the name of the parameter
	 * 
	 * @return the parameter index. The first parameter is 1, the second is 2, and so on
	 * 
	 * @throws SQLException
	 */
	private int getParameterIndex(String parameterName) throws SQLException {
		int i = parameterList.indexOf(new Parameter(parameterName)) + 1;
		if (i < 1) {
			throw new SQLException(String.format("Could not find parameter with name %s", parameterName));
		}
		return i;
	}

	/**
	 * Saves the parameter value.
	 * 
	 * @param parameterName the name of the parameter
	 * @param parameterValue the parameter value
	 * 
	 * @return the parameter index. The first parameter is 1, the second is 2, and so on
	 * 
	 * @throws SQLException
	 */
	private int setParameterValue(String parameterName, Object parameterValue) throws SQLException {
		int i = getParameterIndex(parameterName);
		parameterList.get(i - 1).setValue(parameterValue); // first array index is 0
		return i;
	}
	
	/**
	 * Retrieves this <code>SimpleCall</code> object's parsed SQL statement that may contain one or more <code>?</code> parameter placeholders when not all parameter values are set.
	 * 
	 * @return the parsed SQL statement
	 */
	private String parsedSql() {
		String parsedSql = jdbcSql;
		for (Parameter parameter : parameterList) {			
			parsedSql = StringUtils.replace(parsedSql, "?", parameter.getValueAsString(), 1);
		}
		return parsedSql;
	}

}
