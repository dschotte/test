package com.proximus.cds.oracle12int;

import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.UUID;

import org.apache.commons.lang3.RandomStringUtils;

import com.proximus.cds.oracle12.JdbcUtils;

public class Test {

	public static void main(String[] args) {
		Connection conn = null;
		try {
			conn = (new OracleDataSource()).getConnection();
			CustomerDao dao = new CustomerDao(conn);

			List<Customer> customers = dao.findCustomers();

			for (Customer customer : customers) {
				System.out.println(customer);
			}

			UUID id = UUID.randomUUID();
			Customer customer = new Customer();
			customer.id = id;
			customer.age = Integer.valueOf("49");
			customer.name = "Test";
			customer.isMember = true;
			customer.orderSeq = Long.valueOf("9999999990");
			customer.fee = Double.valueOf("99999990.90");
			customer.remark = "remark " + RandomStringUtils.random(50, "xyz") + " end of remark";
			customer.jsonDoc = "{\"fruit\": \"Pear\", \"size\": \"" +  RandomStringUtils.random(50, "json") + "\", \"color\": \"Red\"}";
			customer.xmlDoc = "<remark>" + RandomStringUtils.random(50, "xml") + "</remark>";
			customer.createdOn = LocalDate.now();
			customer.creationTime = LocalTime.now();
			customer.modifiedAt = LocalDateTime.now();
			customer.linkedId = null;
			dao.createCustomer(customer);
			
			customer = dao.getCustomer(id);
			System.out.println(customer);
			
			customer = dao.getCustomer(null);
			System.out.println(customer);
			
			conn.commit();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.closeQuietly(conn);			
		}
	}	
	
}
