CREATE OR REPLACE FUNCTION find_customers RETURN SYS_REFCURSOR IS
	v_result SYS_REFCURSOR;
BEGIN
	OPEN v_result FOR SELECT id, age, name, is_member, order_seq, fee, remark, json_doc, xml_doc, created_on, creation_time, modified_at, lnk_id
	--OPEN v_result FOR SELECT id, age, name, is_member, order_seq, fee, remark, json_doc, XMLSERIALIZE(CONTENT xml_doc NO INDENT) AS xml_doc, created_on, creation_time, modified_at, lnk_id
	FROM customer
	ORDER BY created_on, creation_time;
	--
	RETURN v_result;
END;
