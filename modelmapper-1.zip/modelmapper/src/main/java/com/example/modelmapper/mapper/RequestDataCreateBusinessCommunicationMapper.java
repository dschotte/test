package com.example.modelmapper.mapper;

import org.modelmapper.ModelMapper;
import org.modelmapper.config.Configuration.AccessLevel;

public class RequestDataCreateBusinessCommunicationMapper {
	
	public static bc.web.api.capability.business.b170.cbu.services.businesscommunication.v3.RequestDataCreateBusinessCommunication mapV2toV3(bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.RequestDataCreateBusinessCommunication v2) {
		ModelMapper modelMapper = new ModelMapper();
		modelMapper.getConfiguration().setFieldMatchingEnabled(true).setFieldAccessLevel(AccessLevel.PROTECTED);
		return modelMapper.map(v2, bc.web.api.capability.business.b170.cbu.services.businesscommunication.v3.RequestDataCreateBusinessCommunication.class);		
	}

}
