package com.example.modelmapper.wrapper;

public class XmlValidatorWrapperException extends Exception {

	private static final long serialVersionUID = 1L;

	public XmlValidatorWrapperException(Throwable cause) {
		super(cause);
	}

}
