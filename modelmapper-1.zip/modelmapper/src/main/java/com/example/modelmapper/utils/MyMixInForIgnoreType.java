package com.example.modelmapper.utils;

import com.fasterxml.jackson.annotation.JsonIgnoreType;

@JsonIgnoreType
public class MyMixInForIgnoreType {}
