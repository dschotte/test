package com.example.modelmapper.wrapper;

public class JaxbWrapperException extends Exception {

	private static final long serialVersionUID = 1L;

	public JaxbWrapperException(Throwable cause) {
		super(cause);
	}

}
