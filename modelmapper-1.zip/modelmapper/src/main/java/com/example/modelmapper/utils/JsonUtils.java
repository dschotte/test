package com.example.modelmapper.utils;

import java.io.IOException;
import java.util.TimeZone;

import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.TreeNode;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.databind.ser.FilterProvider;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import com.fasterxml.jackson.databind.util.StdDateFormat;
import com.fasterxml.jackson.module.jaxb.JaxbAnnotationModule;

import bc.web.api.capability.business.b170.cbu.objects.requestupdatebusinesscommunication.v2.UpdateStringType;

public class JsonUtils {
	
	@SuppressWarnings("serial")
	private static class SerializerForUpdateAttributeType extends StdSerializer<bc.web.api.capability.business.b170.cbu.objects.requestupdatebusinesscommunication.v2.UpdateAttributeType>{
		 
		protected SerializerForUpdateAttributeType(Class<bc.web.api.capability.business.b170.cbu.objects.requestupdatebusinesscommunication.v2.UpdateAttributeType> t) {
			super(t);
		}

		@Override
		public void serialize(bc.web.api.capability.business.b170.cbu.objects.requestupdatebusinesscommunication.v2.UpdateAttributeType updateAttribute, JsonGenerator gen, SerializerProvider serializers) throws IOException, JsonProcessingException {
			gen.writeString(updateAttribute.value());
		}
	
	}

	
	@SuppressWarnings("serial")
	private static class SerializerForUpdateStringType extends StdSerializer<bc.web.api.capability.business.b170.cbu.objects.requestupdatebusinesscommunication.v2.UpdateStringType>{
		 
		protected SerializerForUpdateStringType(Class<bc.web.api.capability.business.b170.cbu.objects.requestupdatebusinesscommunication.v2.UpdateStringType> t) {
			super(t);
		}

		@Override
		public void serialize(bc.web.api.capability.business.b170.cbu.objects.requestupdatebusinesscommunication.v2.UpdateStringType updateString, JsonGenerator gen, SerializerProvider serializers) throws IOException, JsonProcessingException {
			gen.writeString(updateString.getValue());
		}
	
	}

	@SuppressWarnings("serial")
	private static class SerializerForUpdateDateTimeType extends StdSerializer<bc.web.api.capability.business.b170.cbu.objects.requestupdatebusinesscommunication.v2.UpdateDateTimeType>{
		 
		protected SerializerForUpdateDateTimeType(Class<bc.web.api.capability.business.b170.cbu.objects.requestupdatebusinesscommunication.v2.UpdateDateTimeType> t) {
			super(t);
		}

		@Override
		public void serialize(bc.web.api.capability.business.b170.cbu.objects.requestupdatebusinesscommunication.v2.UpdateDateTimeType updateDateTime, JsonGenerator gen, SerializerProvider serializers) throws IOException, JsonProcessingException {
			gen.writeString(updateDateTime.getValue().toString());
		}
	
	}	

	private static ObjectMapper mapper;

	static {
		mapper = new ObjectMapper();
		mapper.registerModule(new JaxbAnnotationModule());
		
		//mapper.setVisibility(PropertyAccessor.ALL, Visibility.NONE);
		//mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
  
		SimpleModule module = new SimpleModule();
		//module.addSerializer(new SerializerForUpdateAttributeType(bc.web.api.capability.business.b170.cbu.objects.requestupdatebusinesscommunication.v2.UpdateAttributeType.class));
		module.addSerializer(new SerializerForUpdateStringType(bc.web.api.capability.business.b170.cbu.objects.requestupdatebusinesscommunication.v2.UpdateStringType.class));
		module.addSerializer(new SerializerForUpdateDateTimeType(bc.web.api.capability.business.b170.cbu.objects.requestupdatebusinesscommunication.v2.UpdateDateTimeType.class));
		mapper.registerModule(module);
		
		mapper.addMixIn(bc.web.api.capability.business.b170.cbu.objects.requestupdatebusinesscommunication.v2.UpdateAttributeType.class, MyMixInForIgnoreType.class);

  
		//mapper.setSerializationInclusion(Include.NON_NULL);
		mapper.setSerializationInclusion(Include.NON_EMPTY);
		mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
		mapper.setDateFormat(new StdDateFormat().withTimeZone(TimeZone.getDefault()).withColonInTimeZone(true));
		
		mapper.setTimeZone(TimeZone.getDefault());		
	}

	public static String toJson(Object object) {
		try {
			
			//FilterProvider filters = new SimpleFilterProvider().addFilter("filter properties by name", SimpleBeanPropertyFilter.serializeAllExcept("updateAction"));
			
			return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(object); // should be without pretty printer to reduce payload
		} catch (JsonProcessingException e) {
			throw new RuntimeException("Could not serialize to json", e);
		}
 	
	}

	public static <T> T fromJson(String json, Class<T> clazz) {
		try {
			return mapper.readValue(json, clazz);
		} catch (JsonProcessingException e) {
			throw new RuntimeException("Could not deserialize from json", e);
		}
	}
	
}
