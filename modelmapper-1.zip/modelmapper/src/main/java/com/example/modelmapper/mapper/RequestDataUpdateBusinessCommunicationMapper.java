package com.example.modelmapper.mapper;

import org.modelmapper.ModelMapper;

public class RequestDataUpdateBusinessCommunicationMapper {
	
	public static bc.web.api.capability.business.b170.cbu.services.businesscommunication.v3.RequestDataUpdateBusinessCommunication mapV2toV3(bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.RequestDataUpdateBusinessCommunication v2) {
		ModelMapper modelMapper = new ModelMapper();
		return modelMapper.map(v2, bc.web.api.capability.business.b170.cbu.services.businesscommunication.v3.RequestDataUpdateBusinessCommunication.class);		
	}

}
