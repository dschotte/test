package com.example.mapstruct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ModelMapperApplicationTests {

	@Test
	void contextLoads() {
	}

}
