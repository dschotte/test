package com.example.modelmapper.mapper;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.modelmapper.utils.JsonUtils;
import com.example.modelmapper.utils.XmlUtils;
import com.example.modelmapper.wrapper.JaxbWrapper;
import com.example.modelmapper.wrapper.JaxbWrapperException;

@SpringBootTest
public class UpdateV2ToCreateV2JsonMapperTests {
		
	@Test
	void shouldMap() throws IOException, JaxbWrapperException {
		Path path = Paths.get("src/test/resources/RequestDataUpdateBusinessCommunication.xml");	 
	    String updateXml = XmlUtils.formatXml(Files.readAllLines(path).stream().collect(Collectors.joining("\n")));
	    System.err.println(updateXml);
	    
	    bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.RequestDataUpdateBusinessCommunication updateRequest = JaxbWrapper.unmarshal(updateXml, bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.RequestDataUpdateBusinessCommunication.class);
	    String updatedBcJson = JsonUtils.toJson(updateRequest.getServiceData().getBusinessCommunication());
	    System.out.println(updatedBcJson);
	    

	    bc.web.api.capability.business.b170.cbu.objects.requestcreatebusinesscommunication.v2.BusinessCommunicationType bc = JsonUtils.fromJson(updatedBcJson, bc.web.api.capability.business.b170.cbu.objects.requestcreatebusinesscommunication.v2.BusinessCommunicationType.class);
	    String bcJson = JsonUtils.toJson(bc);
	    System.err.println(bcJson);
	    
		assertThat(bcJson).isEqualTo(updatedBcJson);
	}

}
