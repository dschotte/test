package com.example.modelmapper.mapper;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.modelmapper.utils.JsonUtils;
import com.example.modelmapper.utils.XmlUtils;
import com.example.modelmapper.wrapper.JaxbWrapper;
import com.example.modelmapper.wrapper.JaxbWrapperException;

@SpringBootTest
public class UpdateV2toV3JsonMapperTests {
		
	@Test
	void shouldMap() throws IOException, JaxbWrapperException {
		Path path = Paths.get("src/test/resources/RequestDataUpdateBusinessCommunication.xml");	 
	    String xml2 = XmlUtils.formatXml(Files.readAllLines(path).stream().collect(Collectors.joining("\n")));
	    System.err.println(xml2);  

	    bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.RequestDataUpdateBusinessCommunication v2 = JaxbWrapper.unmarshal(xml2, bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.RequestDataUpdateBusinessCommunication.class);
	    String json2 = JsonUtils.toJson(v2);
	    System.out.println(json2);
	    	    
	    bc.web.api.capability.business.b170.cbu.services.businesscommunication.v3.RequestDataUpdateBusinessCommunication v3 = JsonUtils.fromJson(json2, bc.web.api.capability.business.b170.cbu.services.businesscommunication.v3.RequestDataUpdateBusinessCommunication.class);
	    String json3 = JsonUtils.toJson(v3);
	    System.err.println(json3);
	    
	    String xml3 = XmlUtils.formatXml(JaxbWrapper.marshal(v3, bc.web.api.capability.business.b170.cbu.services.businesscommunication.v3.RequestDataUpdateBusinessCommunication.class));
	    System.out.println(xml3);
	    		
		assertThat(json3).isEqualTo(json2);
		assertThat(xml3).isEqualTo(xml2.replaceAll("businesscommunication/v2", "businesscommunication/v3"));
	}

}