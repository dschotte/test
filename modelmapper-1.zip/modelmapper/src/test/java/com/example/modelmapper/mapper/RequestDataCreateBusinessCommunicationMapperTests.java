package com.example.modelmapper.mapper;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.modelmapper.utils.JsonUtils;
import com.example.modelmapper.wrapper.JaxbWrapper;
import com.example.modelmapper.wrapper.JaxbWrapperException;

@SpringBootTest
public class RequestDataCreateBusinessCommunicationMapperTests {
		
	@Test
	void shouldMap() throws IOException, JaxbWrapperException {
		Path path = Paths.get("src/test/resources/RequestDataCreateBusinessCommunication.xml");	 
	    String xml = Files.readAllLines(path).stream().collect(Collectors.joining("\n"));
	    bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.RequestDataCreateBusinessCommunication v2 = JaxbWrapper.unmarshal(xml, bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.RequestDataCreateBusinessCommunication.class);
	    String json2 = JsonUtils.toJson(v2);
	    System.out.println(json2);
	    
	    bc.web.api.capability.business.b170.cbu.services.businesscommunication.v3.RequestDataCreateBusinessCommunication v3 = RequestDataCreateBusinessCommunicationMapper.mapV2toV3(v2);
	    String json3 = JsonUtils.toJson(v3);
	    System.err.println(json3);
		
		assertThat(json3).isEqualTo(json2);
	}

}
