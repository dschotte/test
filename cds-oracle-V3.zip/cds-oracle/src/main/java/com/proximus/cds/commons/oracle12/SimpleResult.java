package com.proximus.cds.commons.oracle12;

import java.sql.Blob;
import java.sql.Clob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import oracle.xdb.XMLType;

public class SimpleResult implements AutoCloseable {
	
	private ResultSet rs;

	/**
	 * Creates a <code>SimpleResult</code> object that wraps a given <code>ResultSet</code> object that maintains a cursor that moves forward only.
	 * 
	 * @param rs the <code>ResultSet</code> object
	 */
	protected SimpleResult(ResultSet rs) {
		this.rs = rs;
	}
	
	/**
	 * Moves the <code>SimpleResult</code> cursor forward one row from its current position. A <code>SimpleResult</code> cursor is initially positioned before the first row; the first call to the method next makes the first row the current row; the second call makes the second row the current row, and so on.
	 * 
	 * @return <code>true</code> if the new current row is valid; <code>false</code> if there are no more rows
	 * 
	 * @throws SQLException
	 */
	public boolean next() throws SQLException {
		return rs.next();
	}

	/**
	 * Retrieves the value of a <code>ParameterOrColumnType.BLOB</code> column in the current row of the <code>SimpleResult</code> as an array of <code>byte</code> values.
	 * 
	 * @param columnLabel the label for the column specified with the SQL AS clause. If the SQL AS clause was not specified, then the label is the name of the column
	 * 
	 * @return the parameter value. If the value is SQL NULL, the result is null
	 * 
	 * @throws SQLException
	 */
	public byte[] getBlobAsBytes(String columnLabel) throws SQLException {
	   	Blob blob = null;
		try {
			blob = rs.getBlob(columnLabel);
			if (rs.wasNull()) {
				return null;
			}
			return blob.getBytes(1, (int) blob.length());
		} finally {
			JdbcUtils.freeQuietly(blob);
		}		
	}

	/**
	 * Retrieves the value of a <code>ParameterOrColumnType.BYTES</code> column in the current row of the <code>SimpleResult</code> as an array of <code>byte</code> values. Works with Oracle RAW and BLOB source columns, but always use {@link #getBlobAsBytes} with a temporary BLOB.
	 * 
	 * @param columnLabel the label for the column specified with the SQL AS clause. If the SQL AS clause was not specified, then the label is the name of the column
	 * 
	 * @return the parameter value. If the value is SQL NULL, the result is null
	 * 
	 * @throws SQLException
	 */
	public byte[] getBytes(String columnLabel) throws SQLException {
		byte[] bytes = rs.getBytes(columnLabel);
		if (rs.wasNull()) {
			return null;
		}
		return bytes;
	}

	/**
	 * Retrieves the value of a <code>ParameterOrColumnType.CLOB</code> column in the current row of the <code>SimpleResult</code> as a <code>String</code>.
	 * 
	 * @param columnLabel the label for the column specified with the SQL AS clause. If the SQL AS clause was not specified, then the label is the name of the column
	 * 
	 * @return the parameter value. If the value is SQL NULL, the result is null
	 * 
	 * @throws SQLException
	 */
	public String getClobAsString(String columnLabel) throws SQLException {
		Clob clob = null;
		try {
			clob = rs.getClob(columnLabel);			
			if (rs.wasNull()) {
				return null;
			}
			return clob.getSubString(1, (int) clob.length());
		} finally {
			JdbcUtils.freeQuietly(clob);
		}		
	}	

	/**
	 * Retrieves the value of a <code>ParameterOrColumnType.DOUBLE</code> column in the current row of the <code>SimpleResult</code> as a <code>double</code>.
	 * 
	 * @param columnLabel the label for the column specified with the SQL AS clause. If the SQL AS clause was not specified, then the label is the name of the column
	 * 
	 * @return the parameter value. If the value is SQL NULL, the result is 0
	 * 
	 * @throws SQLException
	 */
	public double getDouble(String columnLabel) throws SQLException {
		return rs.getDouble(columnLabel);
	}

	/**
	 * Retrieves the value of a <code>ParameterOrColumnType.INT</code> column in the current row of the <code>SimpleResult</code> as a <code>int</code>.
	 * 
	 * @param columnLabel the label for the column specified with the SQL AS clause. If the SQL AS clause was not specified, then the label is the name of the column
	 * 
	 * @return the parameter value. If the value is SQL NULL, the result is 0
	 * 
	 * @throws SQLException
	 */
	public int getInt(String columnLabel) throws SQLException {
		return rs.getInt(columnLabel);
	}

	/**
	 * Retrieves the value of a <code>ParameterOrColumnType.LOCAL_DATE</code> column in the current row of the <code>SimpleResult</code> as a <code>LocalDate</code>.
	 * 
	 * @param columnLabel the label for the column specified with the SQL AS clause. If the SQL AS clause was not specified, then the label is the name of the column
	 * 
	 * @return the parameter value. If the value is SQL NULL, the result is null
	 * 
	 * @throws SQLException
	 */
	public LocalDate getLocalDate(String columnLabel) throws SQLException {
		java.sql.Date date = rs.getDate(columnLabel);
		if (rs.wasNull()) {
			return null;
		}
		return date.toLocalDate();
	}

	/**
	 * Retrieves the value of a <code>ParameterOrColumnType.LOCAL_DATE_TIME</code> column in the current row of the <code>SimpleResult</code> as a <code>LocalDateTime</code>.
	 * 
	 * @param columnLabel the label for the column specified with the SQL AS clause. If the SQL AS clause was not specified, then the label is the name of the column
	 * 
	 * @return the parameter value. If the value is SQL NULL, the result is null
	 * 
	 * @throws SQLException
	 */
	public LocalDateTime getLocalDateTime(String columnLabel) throws SQLException {
		java.sql.Timestamp timestamp = rs.getTimestamp(columnLabel);
		if (rs.wasNull()) {
			return null;
		}
		return timestamp.toLocalDateTime();
	}	

	/**
	 * Retrieves the value of a <code>ParameterOrColumnType.LOCAL_TIME</code> column in the current row of the <code>SimpleResult</code> as a <code>LocalTime</code>.
	 * 
	 * @param columnLabel the label for the column specified with the SQL AS clause. If the SQL AS clause was not specified, then the label is the name of the column
	 * 
	 * @return the parameter value. If the value is SQL NULL, the result is null
	 * 
	 * @throws SQLException
	 */
	public LocalTime getLocalTime(String columnLabel) throws SQLException {
		java.sql.Time time = rs.getTime(columnLabel);
		if (rs.wasNull()) {
			return null;
		}
		return time.toLocalTime();
	}

	/**
	 * Retrieves the value of a <code>ParameterOrColumnType.LONG</code> column in the current row of the <code>SimpleResult</code> as a <code>long</code>.
	 * 
	 * @param columnLabel the label for the column specified with the SQL AS clause. If the SQL AS clause was not specified, then the label is the name of the column
	 * 
	 * @return the parameter value. If the value is SQL NULL, the result is 0
	 * 
	 * @throws SQLException
	 */	
	public long getLong(String columnLabel) throws SQLException {
		return rs.getLong(columnLabel);
	}	

	/**
	 * Retrieves the value of a <code>ParameterOrColumnType.STRING</code> column in the current row of the <code>SimpleResult</code> as a <code>String</code>. Works with Oracle *CHAR* and *CLOB source columns, but always use {@link #getClobAsString} with a temporary CLOB.
	 * 
	 * @param columnLabel the label for the column specified with the SQL AS clause. If the SQL AS clause was not specified, then the label is the name of the column
	 * 
	 * @return the parameter value. If the value is SQL NULL, the result is null
	 * 
	 * @throws SQLException
	 */
	public String getString(String columnLabel) throws SQLException {
		return rs.getString(columnLabel);
	}

	/**
	 * Retrieves the value of a <code>ParameterOrColumnType.UUID</code> column in the current row of the <code>SimpleResult</code> as a <code>UUID</code>.
	 * 
	 * @param columnLabel the label for the column specified with the SQL AS clause. If the SQL AS clause was not specified, then the label is the name of the column
	 * 
	 * @return the parameter value. If the value is SQL NULL, the result is null
	 * 
	 * @throws SQLException
	 */
	public UUID getUUID(String columLabel) throws SQLException {
		byte[] bytes = rs.getBytes(columLabel);
		if (rs.wasNull()) {
			return null;
		}
		return UUIDUtils.toUUID(bytes);
	}

	/**
	 * Retrieves the value of a <code>ParameterOrColumnType.XML_TYPE</code> column in the current row of the <code>SimpleResult</code> as a <code>String</code>.
	 * 
	 * @param columnLabel the label for the column specified with the SQL AS clause. If the SQL AS clause was not specified, then the label is the name of the column
	 * 
	 * @return the parameter value. If the value is SQL NULL, the result is null
	 * 
	 * @throws SQLException
	 */
	public String getXMLTypeAsString(String columnLabel) throws SQLException {
		XMLType xml = null;	
		try {
			xml = (XMLType) rs.getObject(columnLabel); 
			if (rs.wasNull()) {
				return null;
			}
			return xml.getString();
		} finally {
			JdbcUtils.freeQuietly(xml);
		}
	}
	
	/**
	 * Moves the <code>SimpleResult</code> cursor forward one row from its current position, mapping one row to a result object via a <code>RowMapper</code>.
	 * 
	 * @param rowMapper a callback that will map one row to an object
	 * 
	 * @return a mapped object; null if there are no more rows
	 * 
	 * @throws SQLException
	 */
	public <T> T nextAndLastRow(RowMapper<T> rowMapper) throws SQLException {
        T row = null;
        try {
            if (rs.next()) {
                row = rowMapper.mapRow(this);
                if (rs.next()) throw new SQLException("There are more rows than expected");
            }
        } finally {
            rs.close(); // as cursor moves forward only
        }
        return row;
    }    	

	/**
	 * Moves the <code>SimpleResult</code> cursor forward row by row from its current position, mapping each row to a result object via a <code>RowMapper</code>.
	 * 
	 * @param rowMapper a callback that will map each row to an object
	 * 
	 * @return a <code>List</code>, containing mapped objects; empty if there are no more rows
	 * 
	 * @throws SQLException
	 */
    public <T> List<T> nextRows(RowMapper<T> rowMapper) throws SQLException {
        List<T> rows = new ArrayList<T>();
        try {
            while (rs.next()) {
                rows.add(rowMapper.mapRow(this));
            }
        } finally {
            rs.close(); // as cursor moves forward only
        }
        return rows;
    }

	/**
	 * Releases the <code>SimpleResult</code> object's resources. It is good practice to release resources as soon as you are finished with them.
	 * 
	 * @throws SQLException
	 */
	public void close() throws SQLException {
		rs.close();
	}

}
