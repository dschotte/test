package com.proximus.cds.commons.oracle12;

import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class Parameter {
	
	protected static final Pattern PLACEHOLDER = Pattern.compile("(?<!')(:[\\w]*)(?!')"); // :name
	
	private String name;
	private String valueAsString;
	
	/**
	 * Creates a <code>Parameter</code> with the given name.
	 * 
	 * @param name the name
	 */
	protected Parameter(String name) {
		this.name = name;
	}

	/**
	 * Returns the name of this parameter.
	 * 
	 * @return the name
	 */
	protected String getName() {
		return name;
	}

	/**
	 * Returns the value of this parameter as a <code>String</code> object.
	 * 
	 * @return the value
	 */
	protected String getValueAsString() {
		return StringUtils.defaultString(valueAsString, "NULL");
	}
	
	/**
	 * Sets the value of this parameter.
	 * 
	 * @param x the value
	 */
	protected void setValue(Object x) {
		if (x != null) {
			valueAsString = x.toString();
		} else {
			valueAsString = null;
		}
	}

	/**
	 * Returns a hash code for this parameter.
	 * 
	 * @return the hash code
	 */
	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(name).toHashCode();
	}

	/**
	 * Compares this object to another object. The result is true if and only if the argument is not null, is a <code>Parameter</code> object, and has the same name as this parameter.
	 * 
	 * @param other the other object
	 */
	@Override
	public boolean equals(Object other) {
		if (other instanceof Parameter == false) {
			return false;
		}
		return new EqualsBuilder().append(this.name, ((Parameter) other).name).isEquals();
	}
	
	/**
	 * Returns a <code>String</code> object representing this parameter.
	 * 
	 * @return the <code>String</code> object
	 */
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
	
}
