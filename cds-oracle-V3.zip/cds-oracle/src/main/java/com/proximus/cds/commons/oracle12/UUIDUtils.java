package com.proximus.cds.commons.oracle12;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.UUID;

public class UUIDUtils {
	
	/**
	 * Creates an array of <code>byte</code> values based on the given <code>UUID</code>
	 * 
	 * @param uuid a <code>UUID</code>
	 * 
	 * @return the created array of <code>byte</code> values
	 */
	protected static byte[] toBytes(UUID uuid) {
        byte[] bytes = new byte[16];
        ByteBuffer.wrap(bytes).order(ByteOrder.BIG_ENDIAN).putLong(uuid.getMostSignificantBits()).putLong(uuid.getLeastSignificantBits());
        return bytes;
    }

	/**
	 * Creates a <code>UUID</code> based on the given array of <code>byte</code> values
	 * 
	 * @param bytes an array of <code>byte</code> values
	 * 
	 * @return the created <code>UUID</code>
	 */
	protected static UUID toUUID(byte[] bytes) {
		ByteBuffer byteBuffer = ByteBuffer.wrap(bytes);
        Long high = byteBuffer.getLong();
        Long low = byteBuffer.getLong();
        return new UUID(high, low);
	}
	
}
