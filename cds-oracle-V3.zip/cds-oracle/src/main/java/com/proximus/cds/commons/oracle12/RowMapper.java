package com.proximus.cds.commons.oracle12;

import java.sql.SQLException;

public interface RowMapper<T> {

	/**
	 * Implementations must implement this method to map each row of data in the <code>SimpleResult</code>. This method should not call <code>next()</code> on the <code>SimpleResult</code>; it is only supposed to map values of the current row.
	 * 
	 * @param r the <code>SimpleResult</code> to map (pre-initialized for the current row)
	 * 
	 * @return the result object for the current row; may be null
	 * 
	 * @throws SQLException
	 */
	T mapRow(SimpleResult r) throws SQLException;
	
}
