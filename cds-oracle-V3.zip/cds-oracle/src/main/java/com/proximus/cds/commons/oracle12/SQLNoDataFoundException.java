package com.proximus.cds.commons.oracle12;

import java.sql.SQLException;

public class SQLNoDataFoundException extends SQLException {

	private static final long serialVersionUID = 1L;

	protected static final int ERROR_CODE = 1403; // ORA-1403 NO_DATA_FOUND
	
	/**
	 * Constructs a <code>SQLNoDataFoundException</code> object. The <code>reason</code>, <code>SQLState</code>, <code>errorCode</code> (must be 1403) and <code>cause</code> are initialized to the values of the given <code>SQLException</code>.
	 * 
	 * @param e the <code>SQLException</code> with <code>errorCode</code> 1403
	 */
	protected SQLNoDataFoundException(SQLException e) {
		super(e.getMessage(), e.getSQLState(), e.getErrorCode(), e.getCause());
		if (e.getErrorCode() != ERROR_CODE) {
			throw new IllegalArgumentException("Not ORA-1403");
		}
	}
	
}
