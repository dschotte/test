package com.proximus.cds.commons.oracle12int;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

import org.apache.commons.codec.binary.StringUtils;
import org.apache.commons.lang3.BooleanUtils;

import com.proximus.cds.commons.oracle12.JdbcUtils;
import com.proximus.cds.commons.oracle12.ParameterOrColumnType;
import com.proximus.cds.commons.oracle12.RowMapper;
import com.proximus.cds.commons.oracle12.SQLNoDataFoundException;
import com.proximus.cds.commons.oracle12.SimpleCall;
import com.proximus.cds.commons.oracle12.SimpleResult;

public class CustomerDao {
	
	private Connection conn;
	
	private class CustomerRowMapper implements RowMapper<Customer> {
		@Override public Customer mapRow(SimpleResult r) throws SQLException {
			Customer customer = new Customer();
			customer.id = r.getUUID("id");
			customer.age = r.getInt("age");
			customer.name = r.getString("name");
			customer.isMember = BooleanUtils.toBoolean(r.getString("is_member"), "Y", "N");
			customer.orderSeq = r.getLong("order_seq");
			customer.fee = r.getDouble("fee");
			customer.remark = r.getClobAsString("remark");
			customer.jsonDoc = StringUtils.newStringUtf8(r.getBytes("json_doc"));
			//customer.xmlDoc = r.getXMLTypeAsString("xml_doc");
			customer.xmlDoc = r.getClobAsString("xml_doc_2"); // test temporary clob
			customer.createdOn = r.getLocalDate("created_on");
			customer.creationTime = r.getLocalTime("creation_time");
			customer.modifiedAt = r.getLocalDateTime("modified_at");
			customer.linkedId = r.getUUID("lnk_id");
			return customer;
		}
	}
	
	public CustomerDao(Connection conn) {
		super();
		this.conn = conn;
	}

	public List<Customer> findCustomers() throws SQLException {
		SimpleCall c = null;
		try {
			c = new SimpleCall(conn, "{ :result = call find_customers }");
			c.registerOutParameter("result", ParameterOrColumnType.CURSOR);
			
			c.execute();
			
			return c.getCursor("result").nextRows(new CustomerRowMapper());
		} finally {
			JdbcUtils.closeQuietly(c);
		}
	}

	public void createCustomer(Customer customer) throws SQLException {
		SimpleCall c = null;
		try {
			c = new SimpleCall(conn, "{ call create_customer(:id, :age, :name, :is_member, :order_seq, :fee, :remark, :json_doc, :xml_doc, :created_on, :creation_time, :modified_at, :lnk_id) }");
			c.setUUID("id", customer.id);
			c.setInt("age", customer.age);
			c.setString("name", customer.name);
			c.setString("is_member", BooleanUtils.toString(customer.isMember, "Y", "N"));
			c.setLong("order_seq", customer.orderSeq);
			c.setDouble("fee", customer.fee);
			c.setString("remark", customer.remark);
			c.setBytes("json_doc", StringUtils.getBytesUtf8(customer.jsonDoc));
			c.setXMLType("xml_doc", customer.xmlDoc);
			c.setLocalDate("created_on", customer.createdOn);
			c.setLocalTime("creation_time", customer.creationTime);
			c.setLocalDateTime("modified_at", customer.modifiedAt);
			c.setUUID("lnk_id", customer.linkedId);
			
			c.execute();
		} finally {
			JdbcUtils.closeQuietly(c);
		}		
	}

	public Customer getCustomerOut(UUID id) throws SQLException {
		SimpleCall c = null;
		try {
			c = new SimpleCall(conn, "{ call get_customer_out(:id, :age, :name, :is_member, :order_seq, :fee, :remark, :json_doc, :xml_doc, :xml_doc_2, :created_on, :creation_time, :modified_at, :lnk_id) }");
			c.setUUID("id", id);
			c.registerOutParameter("age", ParameterOrColumnType.INT);
			c.registerOutParameter("name", ParameterOrColumnType.STRING);
			c.registerOutParameter("is_member", ParameterOrColumnType.STRING);
			c.registerOutParameter("order_seq", ParameterOrColumnType.LONG);
			c.registerOutParameter("fee", ParameterOrColumnType.DOUBLE);
			c.registerOutParameter("remark", ParameterOrColumnType.CLOB);
			c.registerOutParameter("json_doc", ParameterOrColumnType.BYTES);
			c.registerOutParameter("xml_doc", ParameterOrColumnType.XML_TYPE);
			c.registerOutParameter("xml_doc_2", ParameterOrColumnType.CLOB);
			c.registerOutParameter("created_on", ParameterOrColumnType.LOCAL_DATE);
			c.registerOutParameter("creation_time", ParameterOrColumnType.LOCAL_TIME);
			c.registerOutParameter("modified_at", ParameterOrColumnType.LOCAL_DATE_TIME);
			c.registerOutParameter("lnk_id", ParameterOrColumnType.UUID);
			
			c.execute();
			
			Customer customer = new Customer();
			customer.id = id;
			customer.age = c.getInt("age");
			customer.name = c.getString("name");
			customer.isMember = BooleanUtils.toBoolean(c.getString("is_member"), "Y", "N");
			customer.orderSeq = c.getLong("order_seq");
			customer.fee = c.getDouble("fee");
			customer.remark = c.getClobAsString("remark");
			customer.jsonDoc = StringUtils.newStringUtf8(c.getBytes("json_doc"));
			//customer.xmlDoc = c.getXMLTypeAsString("xml_doc");
			customer.xmlDoc = c.getClobAsString("xml_doc_2"); // test temporary clob
			customer.createdOn = c.getLocalDate("created_on");
			customer.creationTime = c.getLocalTime("creation_time");
			customer.modifiedAt = c.getLocalDateTime("modified_at");
			customer.linkedId = c.getUUID("lnk_id");			
			return customer;
		} catch (SQLNoDataFoundException e) {
			return null;
		} finally {
			JdbcUtils.closeQuietly(c);
		}
	}

	public Customer getCustomer(UUID id) throws SQLException {
		SimpleCall c = null;
		try {
			c = new SimpleCall(conn, "{ :result = call get_customer(:id) }");
			c.setUUID("id", id);
			c.registerOutParameter("result", ParameterOrColumnType.CURSOR);
			
			c.execute();
			
			return c.getCursor("result").nextAndLastRow(new CustomerRowMapper());
		} finally {
			JdbcUtils.closeQuietly(c);
		}
	}

}
