CREATE OR REPLACE FUNCTION get_customer(p_id IN RAW) RETURN SYS_REFCURSOR IS
	v_result SYS_REFCURSOR;
BEGIN
	OPEN v_result FOR SELECT id, age, name, is_member, order_seq, fee, remark, json_doc, xml_doc, XMLSERIALIZE(CONTENT xml_doc NO INDENT) AS xml_doc_2, created_on, creation_time, modified_at, lnk_id
	FROM customer
	WHERE id = p_id;
	--
	RETURN v_result;
END;
