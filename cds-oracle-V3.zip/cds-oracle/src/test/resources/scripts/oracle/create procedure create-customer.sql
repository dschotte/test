CREATE OR REPLACE PROCEDURE create_customer(p_id IN RAW, p_age IN NUMBER, p_name IN VARCHAR2, p_is_member IN VARCHAR2, p_order_seq IN NUMBER, p_fee IN NUMBER, p_remark IN CLOB, p_json_doc IN BLOB, p_xml_doc IN XMLTYPE, p_created_on IN DATE, p_creation_time IN DATE, p_modified_at IN TIMESTAMP, p_lnk_id IN RAW) IS
BEGIN
	INSERT INTO customer (id, age, name, is_member, order_seq, fee, remark, json_doc, xml_doc, created_on, creation_time, modified_at, lnk_id)
	VALUES (p_id, p_age, p_name, p_is_member, p_order_seq, p_fee, p_remark, p_json_doc, p_xml_doc, p_created_on, p_creation_time, p_modified_at, p_lnk_id);
END;
