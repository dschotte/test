CREATE OR REPLACE PROCEDURE get_customer_out(p_id IN RAW, p_age OUT NUMBER, p_name OUT VARCHAR2, p_is_member OUT VARCHAR2, p_order_seq OUT NUMBER, p_fee OUT NUMBER, p_remark OUT CLOB, p_json_doc OUT BLOB, p_xml_doc OUT XMLTYPE, p_xml_doc_2 OUT CLOB, p_created_on OUT DATE, p_creation_time OUT DATE, p_modified_at OUT TIMESTAMP, p_lnk_id OUT RAW) IS
BEGIN
	SELECT age, name, is_member, order_seq, fee, remark, json_doc, xml_doc, XMLSERIALIZE(CONTENT xml_doc NO INDENT), created_on, creation_time, modified_at, lnk_id
	INTO p_age, p_name, p_is_member, p_order_seq, p_fee, p_remark, p_json_doc, p_xml_doc, p_xml_doc_2, p_created_on, p_creation_time, p_modified_at, p_lnk_id
	FROM customer
	WHERE id = p_id;
END;
