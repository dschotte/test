package com.example.dozer.builder;

import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.GeographicAddressDesignatorType;

public class GeographicAddressDesignatorBuilder {

	public static GeographicAddressDesignatorType build(String type, String val) {
		GeographicAddressDesignatorType designator = new GeographicAddressDesignatorType();
		designator.setType(CodeValueBuilder.value(type));
		designator.setValue(val);
		return designator;
	}

	public static GeographicAddressDesignatorType hseNr(String val) {
		return build("HOUSE_NUMBER", val);
	}

	public static GeographicAddressDesignatorType hseNrSfx(String val) {
		return build("HOUSE_NUMBER-SUFFIX", val);
	}

	public static GeographicAddressDesignatorType boxNr(String val) {
		return build("BOX_NUMBER", val);
	}

	public static GeographicAddressDesignatorType aptNr(String val) {
		return build("APARTMENT_NUMBER", val);
	}

	public static GeographicAddressDesignatorType blockNr(String val) {
		return build("BLOCK_NUMBER", val);
	}

	public static GeographicAddressDesignatorType floorNr(String val) {
		return build("FLOOR_NUMBER", val);
	}

}
