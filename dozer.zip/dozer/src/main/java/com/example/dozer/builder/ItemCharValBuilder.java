package com.example.dozer.builder;

import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.BusinessCommunicationItemCharValType;

public class ItemCharValBuilder {

	public static BusinessCommunicationItemCharValType build(String nm, String val) {
		BusinessCommunicationItemCharValType charVal = new BusinessCommunicationItemCharValType();
		charVal.setCharacteristicName(NameBuilder.defaultName(nm));
		charVal.setValue(val);
		return charVal;
	}

	public static BusinessCommunicationItemCharValType itemAppId(String val) {
		return build("ITEM_APPLICATION_ID", val);
	}

	public static BusinessCommunicationItemCharValType reqTitle(String val) {
		return build("RequestTitle", val);
	}	

	public static BusinessCommunicationItemCharValType reqId(String val) {
		return build("businessCommunication.item.relationship.businessInteractionIdentifier.requestIdentifier.Id", val);
	}	

	public static BusinessCommunicationItemCharValType reqIdScope(String val) {
		return build("businessCommunication.item.relationship.businessInteractionIdentifier.requestIdentifier.IdScope", val);
	}	

	public static BusinessCommunicationItemCharValType reqIdCtx(String val) {
		return build("businessCommunication.item.relationship.businessInteractionIdentifier.requestIdentifier.IdContext", val);
	}

	public static BusinessCommunicationItemCharValType locAddr(String val) {
		return build(".geographicAddress.locator.geographicAddressDesignator.value", val);
	}	

	public static BusinessCommunicationItemCharValType salesChNm(String val) {
		return build(".salesChannel.name", val);
	}	

	public static BusinessCommunicationItemCharValType salesChAddr(String val) {
		return build(".salesChannel.geographicAddress.locator.geographicAddressDesignator.value", val);
	}	

}
