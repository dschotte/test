package com.example.dozer.mapper;

import com.github.dozermapper.core.DozerBeanMapperBuilder;
import com.github.dozermapper.core.Mapper;

public class RequestDataUpdateBusinessCommunicationMapper {
	
	public static bc.web.api.capability.business.b170.cbu.services.businesscommunication.v3.RequestDataUpdateBusinessCommunication mapV2toV3(bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.RequestDataUpdateBusinessCommunication v2) {
		Mapper mapper = DozerBeanMapperBuilder.buildDefault();
		/*
		Mapper mapper = DozerBeanMapperBuilder.create()
			.withMappingFiles("v2-v3-mapping.xml")
			.build();
		*/
		return mapper.map(v2, bc.web.api.capability.business.b170.cbu.services.businesscommunication.v3.RequestDataUpdateBusinessCommunication.class);
	}

}
