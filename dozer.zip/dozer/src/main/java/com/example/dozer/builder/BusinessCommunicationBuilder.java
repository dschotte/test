package com.example.dozer.builder;

import javax.xml.datatype.XMLGregorianCalendar;

import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.BusinessCommunicationType;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.LanguageCodeISOAlpha2Type;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.StatusType;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.TimeIntervalType;

public class BusinessCommunicationBuilder {
	
	private BusinessCommunicationType bc = new BusinessCommunicationType();

	public BusinessCommunicationType build() {
		return bc;
	}

	public void addIdentifier(String id, String idCtx, String idScope) {
		bc.getIdentifiers().add(IdentifierBuilder.build(id, idCtx, idScope));
	}
	
	public void setInteractionDuration(XMLGregorianCalendar startDt, XMLGregorianCalendar endDt) {
		TimeIntervalType interactionDuration = new TimeIntervalType();
		interactionDuration.setStartTimeStamp(startDt);
		interactionDuration.setEndTimeStamp(endDt);
		bc.setInteractionDuration(interactionDuration);
	}
	
	public void setLanguage(String langCd) {
		LanguageCodeISOAlpha2Type language = new LanguageCodeISOAlpha2Type();
		language.setAlpha2Code(langCd);
		bc.setLanguage(language);
	}

	public void addName(String nm) {
		bc.getNames().add(NameBuilder.defaultName(nm));
	}
	
	public void setStatus(String statCd, XMLGregorianCalendar statStartDt) {
		StatusType status = new StatusType();
		status.setCode(CodeValueBuilder.value(statCd));
		TimeIntervalType validFor = new TimeIntervalType();
		validFor.setStartTimeStamp(statStartDt);
		status.setValidFor(validFor);
		bc.setStatus(status);
	}
	
	public void setDirection(String dirCd) {
		bc.setDirection(CodeValueBuilder.value(dirCd));
	}

	public void setDescription(String descr) {
		bc.setDescription(NameBuilder.defaultName(descr));
	}

	public void setChannelClassification(String chanClassCd) {
		bc.setChannelClassification(CodeValueBuilder.value(chanClassCd));
	}

	public void addCustOrderId(String id, String idCtx, String idScope) {
		bc.getRelationships().add(RelationshipBuilder.custOrderId(id, idCtx, idScope));
	}

	public void addCustId(String id, String idCtx, String idScope) {
		bc.getRoles().add(RoleBuilder.custId(id, idCtx, idScope));
	}

	public void addCreatorAppId(String id) {
		bc.getRoles().add(RoleBuilder.creatorAppId(id));
	}

	public void addSubmitterAppId(String id) {
		bc.getRoles().add(RoleBuilder.submitterAppId(id));
	}

	public void addUpdaterAppId(String id) {
		bc.getRoles().add(RoleBuilder.updaterAppId(id));
	}

	public void addMoodCd(String cd) {
		bc.getRoles().add(RoleBuilder.moodCd(cd));
	}

	public void addAcctId(String id, String idCtx, String idScope) {
		bc.getRoles().add(RoleBuilder.acctId(id, idCtx, idScope));
	}

	public void addTplId(String appId, String val) {
		bc.getCharVals().add(CharValBuilder.tplId(appId, val));
	}

	public void addTplNm(String appId, String val) {
		bc.getCharVals().add(CharValBuilder.tplNm(appId, val));
	}

	public void addTplDescr(String appId, String val) {
		bc.getCharVals().add(CharValBuilder.tplDescr(appId, val));
	}

	public void addCampaignId(String appId, String val) {
		bc.getCharVals().add(CharValBuilder.campaignId(appId, val));
	}

	public void addCampaignNm(String appId, String val) {
		bc.getCharVals().add(CharValBuilder.campaignNm(appId, val));
	}

	public void addSvcNm(String appId, String val) {
		bc.getCharVals().add(CharValBuilder.svcNm(appId, val));
	}

	public void addBcTp(String bcTp) {
		bc.getCharVals().add(CharValBuilder.bcTp(bcTp));
	}	
	
}
