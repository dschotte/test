package com.example.dozer.builder;

import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.CodeValueType;

public class CodeValueBuilder {

	public static CodeValueType codeValue(String cdSystem, String val) {
		CodeValueType codeValue = new CodeValueType();
		codeValue.setCodeSystem(cdSystem);
		codeValue.setValue(val);
		return codeValue;
	}

	public static CodeValueType value(String val) {
		CodeValueType codeValue = new CodeValueType();
		codeValue.setValue(val);
		return codeValue;
	}

}
