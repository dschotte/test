package com.example.dozer.builder;

import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.BusinessCommunicationItemRoleType;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.ChoicePartyRoleIdentifierInCommunicationType;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.EmployeeIdentifierType;

public class ItemRoleBuilder {

	public static BusinessCommunicationItemRoleType empId(String roleTp, String id, String idCtx, String idScope) {
		BusinessCommunicationItemRoleType role = new BusinessCommunicationItemRoleType();
		role.setType(CodeValueBuilder.value(roleTp));
		ChoicePartyRoleIdentifierInCommunicationType choicePartyRoleIdentifierInCommunication = new ChoicePartyRoleIdentifierInCommunicationType();
		EmployeeIdentifierType employeeIdentifier = new EmployeeIdentifierType();
		employeeIdentifier.setId(id);
		employeeIdentifier.setIdContext(CodeValueBuilder.value(idCtx));
		employeeIdentifier.setIdScope(CodeValueBuilder.value(idScope));
		choicePartyRoleIdentifierInCommunication.setEmployeeIdentifier(employeeIdentifier);
		role.setPartyRoleIdentifier(choicePartyRoleIdentifierInCommunication);
		return role;
	}

	public static BusinessCommunicationItemRoleType submitterEmpId(String roleTp, String id, String idCtx, String idScope) {
		return empId("SUBMITTED_BY", id, idCtx, idScope);
	}

	public static BusinessCommunicationItemRoleType handlerEmpId(String roleTp, String id, String idCtx, String idScope) {
		return empId("HandledBy", id, idCtx, idScope);
	}	
	
}
