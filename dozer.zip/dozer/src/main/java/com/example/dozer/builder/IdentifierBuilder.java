package com.example.dozer.builder;

import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.BusinessCommunicationIdentifierType;

public class IdentifierBuilder {

	public static BusinessCommunicationIdentifierType build(String id, String idCtx, String idScope) {
		BusinessCommunicationIdentifierType identifier = new BusinessCommunicationIdentifierType();
		identifier.setId(id);
		identifier.setIdContext(CodeValueBuilder.value(idCtx));
		identifier.setIdScope(CodeValueBuilder.value(idScope));
		return identifier;
	}

}
