package com.example.dozer.utils;

import java.util.TimeZone;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.util.StdDateFormat;

public class JsonUtils {

	public static String serialize(Object object) {
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			
			objectMapper.setTimeZone(TimeZone.getDefault());

			objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
			objectMapper.setDateFormat(StdDateFormat.instance.withColonInTimeZone(true));
			objectMapper.setSerializationInclusion(Include.NON_EMPTY);
			
			return objectMapper.writeValueAsString(object);
		} catch (JsonProcessingException e) {
			throw new RuntimeException("Could not serialize object to json", e);
		}
	}
	
	public static <T> T deserialize(String json, Class<T> clazz) {
		try {
			ObjectMapper objectMapper = new ObjectMapper();

			objectMapper.setTimeZone(TimeZone.getDefault());
			
			return objectMapper.readValue(json, clazz);
		} catch (JsonProcessingException e) {
			throw new RuntimeException("Could not deserialize json", e);
		}
	}

	public static String formatJson(String json) {
		try {
			ObjectMapper objectMapper = new ObjectMapper();

			Object object = objectMapper.readValue(json, Object.class);
			
			return objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(object);
		} catch (JsonProcessingException e) {
			throw new RuntimeException("Could not format json", e);
		}
	}
	
}
