package com.example.dozer.builder;

import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.ApplicationIdentifierType;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.BillingAccountIdentifierType;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.BusinessCommunicationRoleType;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.ChoiceContactMediumIdentifierInCommunicationType;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.ChoicePartyRoleIdentifierInCommunicationType;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.CustomerIdentifierType;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.EMailContactIdentifierType;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.PhoneContactIdentifierType;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.PostalContactIdentifierType;

public class RoleBuilder {

	public static BusinessCommunicationRoleType custId(String id, String idCtx, String idScope) {
		BusinessCommunicationRoleType role = new BusinessCommunicationRoleType();
		role.setType(CodeValueBuilder.value("CREATED_FOR"));
		ChoicePartyRoleIdentifierInCommunicationType choicePartyRoleIdentifierInCommunication = new ChoicePartyRoleIdentifierInCommunicationType();
		CustomerIdentifierType customerIdentifier = new CustomerIdentifierType();
		customerIdentifier.setId(id);
		customerIdentifier.setIdContext(CodeValueBuilder.value(idCtx));
		customerIdentifier.setIdScope(CodeValueBuilder.value(idScope));
		choicePartyRoleIdentifierInCommunication.setCustomerIdentifier(customerIdentifier);
		role.setPartyRoleIdentifier(choicePartyRoleIdentifierInCommunication);
		return role;
	}

	public static BusinessCommunicationRoleType creatorAppId(String id) {
		BusinessCommunicationRoleType role = new BusinessCommunicationRoleType();
		role.setType(CodeValueBuilder.value("CREATED_BY"));
		ApplicationIdentifierType applicationIdentifier = new ApplicationIdentifierType();
		applicationIdentifier.setId(id);
		role.getApplicationIdentifiers().add(applicationIdentifier);
		return role;
	}	

	public static BusinessCommunicationRoleType submitterAppId(String id) {
		BusinessCommunicationRoleType role = new BusinessCommunicationRoleType();
		role.setType(CodeValueBuilder.value("SUBMITTED_BY"));
		ApplicationIdentifierType applicationIdentifier = new ApplicationIdentifierType();
		applicationIdentifier.setId(id);
		role.getApplicationIdentifiers().add(applicationIdentifier);
		return role;
	}	

	public static BusinessCommunicationRoleType updaterAppId(String id) {
		BusinessCommunicationRoleType role = new BusinessCommunicationRoleType();
		role.setType(CodeValueBuilder.value("UPDATED_BY"));
		ApplicationIdentifierType applicationIdentifier = new ApplicationIdentifierType();
		applicationIdentifier.setId(id);
		role.getApplicationIdentifiers().add(applicationIdentifier);
		return role;
	}	

	public static BusinessCommunicationRoleType moodCd(String cd) {
		BusinessCommunicationRoleType role = new BusinessCommunicationRoleType();
		role.setType(CodeValueBuilder.value("UPDATED"));
		role.setMood(CodeValueBuilder.value(cd));
		return role;
	}

	public static BusinessCommunicationRoleType acctId(String id, String idCtx, String idScope) {
		BusinessCommunicationRoleType role = new BusinessCommunicationRoleType();
		role.setType(CodeValueBuilder.value("CREATED_FOR"));
		BillingAccountIdentifierType billingAccountIdentifier = new BillingAccountIdentifierType();
		billingAccountIdentifier.setId(id);
		billingAccountIdentifier.setIdContext(CodeValueBuilder.value(idCtx));
		billingAccountIdentifier.setIdScope(CodeValueBuilder.value(idScope));
		role.getBillingAccountIdentifiers().add(billingAccountIdentifier);
		return role;
	}

	public static BusinessCommunicationRoleType postalCtId(String roleTp, String id, String idCtx, String idScope) {
		BusinessCommunicationRoleType role = new BusinessCommunicationRoleType();
		role.setType(CodeValueBuilder.value(roleTp));
		ChoiceContactMediumIdentifierInCommunicationType choiceContactMediumIdentifierInCommunication = new ChoiceContactMediumIdentifierInCommunicationType();
		PostalContactIdentifierType postalContactIdentifier = new PostalContactIdentifierType();
		postalContactIdentifier.setId(id);
		postalContactIdentifier.setIdContext(CodeValueBuilder.value(idCtx));
		postalContactIdentifier.setIdScope(CodeValueBuilder.value(idScope));
		choiceContactMediumIdentifierInCommunication.setPostalContactIdentifier(postalContactIdentifier);
		role.setContactMediumIdentifier(choiceContactMediumIdentifierInCommunication);
		return role;
	}

	public static BusinessCommunicationRoleType phoneCtId(String roleTp, String id, String idCtx, String idScope) {
		BusinessCommunicationRoleType role = new BusinessCommunicationRoleType();
		role.setType(CodeValueBuilder.value(roleTp));
		ChoiceContactMediumIdentifierInCommunicationType choiceContactMediumIdentifierInCommunication = new ChoiceContactMediumIdentifierInCommunicationType();
		PhoneContactIdentifierType phoneContactIdentifier = new PhoneContactIdentifierType();
		phoneContactIdentifier.setId(id);
		phoneContactIdentifier.setIdContext(CodeValueBuilder.value(idCtx));
		phoneContactIdentifier.setIdScope(CodeValueBuilder.value(idScope));
		choiceContactMediumIdentifierInCommunication.setPhoneContactIdentifier(phoneContactIdentifier);
		role.setContactMediumIdentifier(choiceContactMediumIdentifierInCommunication);
		return role;
	}	

	public static BusinessCommunicationRoleType emailCtId(String roleTp, String id, String idCtx, String idScope) {
		BusinessCommunicationRoleType role = new BusinessCommunicationRoleType();
		role.setType(CodeValueBuilder.value(roleTp));
		ChoiceContactMediumIdentifierInCommunicationType choiceContactMediumIdentifierInCommunication = new ChoiceContactMediumIdentifierInCommunicationType();
		EMailContactIdentifierType emailContactIdentifier = new EMailContactIdentifierType();
		emailContactIdentifier.setId(id);
		emailContactIdentifier.setIdContext(CodeValueBuilder.value(idCtx));
		emailContactIdentifier.setIdScope(CodeValueBuilder.value(idScope));
		choiceContactMediumIdentifierInCommunication.setEMailContactIdentifier(emailContactIdentifier);
		role.setContactMediumIdentifier(choiceContactMediumIdentifierInCommunication);
		return role;
	}	
	
}
