package com.example.dozer.builder;

import com.example.dozer.utils.XmlUtils;

import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.BusinessCommunicationType;
import bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.GetBusinessCommunicationServiceDataResponseType;
import bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.ResponseDataGetBusinessCommunication;

public class Test {

	public static void main(String[] args) {
		BusinessCommunicationBuilder builder = new BusinessCommunicationBuilder();
		builder.id = "uuid";
		builder.idCtx = "CDS";
		builder.idScope = "ENT";
		builder.appId = "OCT";
		builder.tplId =  "template id";
		builder.tplNm = "template name";
		builder.reqId = "REQ123";
		builder.custId = "123456789";
		builder.custIdCtx = "CDBF";
		builder.custIdScope = "ENT";
		BusinessCommunicationType businessCommunication = builder.build();
		
		ResponseDataGetBusinessCommunication response = new ResponseDataGetBusinessCommunication();
		GetBusinessCommunicationServiceDataResponseType serviceData = new GetBusinessCommunicationServiceDataResponseType();
		serviceData.setBusinessCommunication(businessCommunication);
		response.setServiceData(serviceData);
		
		String xml = XmlUtils.marshal(response, ResponseDataGetBusinessCommunication.class);
		System.out.println(XmlUtils.formatXml(xml));
	}

}
