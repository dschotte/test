package com.example.dozer.builder;

import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.PostalContactIdentifierType;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.AttachmentIdentifierType;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.AttachmentType;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.CountryCodeISOAlpha3Type;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.CountryType;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.EMailContactIdentifierType;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.EMailContactType;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.GeographicAddressAreaType;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.GeographicAddressIdentifierType;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.GeographicAddressLocatorType;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.GeographicAddressType;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.PhoneContactIdentifierType;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.PhoneContactType;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.PostalAreaType;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.PostalContactType;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.RoadType;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.TelType;

public class ReferenceObjectBuilder {

	public static EMailContactType emailContact(String id, String emailAddr) {
		EMailContactType emailContact = new EMailContactType();
		EMailContactIdentifierType identifier = new EMailContactIdentifierType();
		identifier.setId(id);
		identifier.setIdScope(CodeValueBuilder.value("MSG"));
		emailContact.setIdentifier(identifier);
		emailContact.setEMailAddress(emailAddr);
		return emailContact;
	}

	public static PhoneContactType phoneContact(String id, String ctryPfx, String natlNr) {
		PhoneContactType phoneContact = new PhoneContactType();
		PhoneContactIdentifierType identifier = new PhoneContactIdentifierType();
		identifier.setId(id);
		identifier.setIdScope(CodeValueBuilder.value("MSG"));
		phoneContact.setIdentifier(identifier );
		TelType phoneNumber = new TelType();
		phoneNumber.setCountryPrefix(CodeValueBuilder.value(ctryPfx));
		phoneNumber.setNationalNumber(natlNr);
		phoneContact.setPhoneNumber(phoneNumber);
		return phoneContact;
	}

	public static PostalContactType postalContact(String id, String geoId) {
		PostalContactType postalContact = new PostalContactType();
		PostalContactIdentifierType identifier = new PostalContactIdentifierType();
		identifier.setId(id);
		identifier.setIdScope(CodeValueBuilder.value("MSG"));
		postalContact.setIdentifier(identifier);
		GeographicAddressIdentifierType geoIdentifier = new GeographicAddressIdentifierType();
		geoIdentifier.setId(geoId);
		geoIdentifier.setIdScope(CodeValueBuilder.value("MSG"));
		postalContact.setGeographicAddressIdentifier(geoIdentifier);
		return postalContact;
	}
	
	
	public static AttachmentType attachment(String id, String lnk) {
		AttachmentType attachment = new AttachmentType();
		AttachmentIdentifierType identifier = new AttachmentIdentifierType();
		identifier.setId(id);
		identifier.setIdScope(CodeValueBuilder.value("MSG"));
		attachment.getIdentifiers().add(identifier);
		attachment.setLink(lnk);
		return attachment;
	}

	public static GeographicAddressType geographicAddress(String id, String streetNm, String hseNr, String hseNrSfx, String boxNr, String aptNr, String blockNr, String floorNr, String zipCd, String localityNm, String ctryCd, String ctryNm) {
		GeographicAddressType geographicAddress = new GeographicAddressType();
		GeographicAddressIdentifierType identifier = new GeographicAddressIdentifierType();
		identifier.setId(id);
		identifier.setIdScope(CodeValueBuilder.value("MSG"));
		geographicAddress.getIdentifiers().add(identifier);
		
		RoadType road = new RoadType();
		road.getNames().add(NameBuilder.defaultName(streetNm));
		geographicAddress.setRoad(road);
		
		GeographicAddressLocatorType locator = new GeographicAddressLocatorType();
		locator.setLevel(CodeValueBuilder.value("POSTALDELIVERYPOINT"));
		locator.getGeographicAddressDesignators().add(GeographicAddressDesignatorBuilder.hseNr(hseNr));
		locator.getGeographicAddressDesignators().add(GeographicAddressDesignatorBuilder.hseNrSfx(hseNrSfx));
		locator.getGeographicAddressDesignators().add(GeographicAddressDesignatorBuilder.boxNr(boxNr));
		geographicAddress.getLocators().add(locator);
		
		locator = new GeographicAddressLocatorType();
		locator.setLevel(CodeValueBuilder.value("ACCESS"));
		locator.getGeographicAddressDesignators().add(GeographicAddressDesignatorBuilder.aptNr(aptNr));
		locator.getGeographicAddressDesignators().add(GeographicAddressDesignatorBuilder.blockNr(blockNr));
		locator.getGeographicAddressDesignators().add(GeographicAddressDesignatorBuilder.floorNr(floorNr));
		geographicAddress.getLocators().add(locator);
		
		PostalAreaType postalArea = new PostalAreaType();
		postalArea.setZIP(CodeValueBuilder.value(zipCd));
		GeographicAddressAreaType geographicAddressArea = new GeographicAddressAreaType();
		geographicAddressArea.getNames().add(NameBuilder.defaultName(localityNm));
		postalArea.getGeographicAddressAreas().add(geographicAddressArea);
		geographicAddress.setPostalArea(postalArea);
		
		CountryType country = new CountryType();
		CountryCodeISOAlpha3Type iso3 = new CountryCodeISOAlpha3Type();
		iso3.setAlpha3Code(ctryCd);
		country.setCodeISO3(iso3);
		country.getNames().add(NameBuilder.defaultName(ctryNm));
		geographicAddress.setCountry(country);
		
		return geographicAddress;
	}
	
}
