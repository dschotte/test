package com.example.dozer.utils;

import java.io.StringReader;
import java.io.StringWriter;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

public class XmlUtils {

    private static final ConcurrentMap<Class<?>, JAXBContext> CONTEXT_MAP = new ConcurrentHashMap<>();

	private static <T> JAXBContext reuseContext(Class<T> clazz) throws JAXBException {
        JAXBContext context = CONTEXT_MAP.get(clazz);
        if (context == null) {
            context = JAXBContext.newInstance(clazz);
            CONTEXT_MAP.putIfAbsent(clazz, context); // concurrent safe put
        }
        return context;
	}

	public static <T> String marshal(Object jaxbElement, Class<T> clazz) {
		try {
			StringWriter writer = new StringWriter();
			reuseContext(clazz).createMarshaller().marshal(jaxbElement, writer);		
			return writer.toString();
		} catch (JAXBException e) {
			throw new RuntimeException("Could not marshal object to xml", e);
		}
	}

	public static <T> T unmarshal(String xml, Class<T> clazz) {
		try {
			StringReader reader = new StringReader(xml);
			Object object = reuseContext(clazz).createUnmarshaller().unmarshal(reader);
			return clazz.cast(object);
		} catch (JAXBException e) {
			throw new RuntimeException("Could not unmarshal xml", e);
		}
	}	

	public static String formatXml(String xml) {
		try {
			TransformerFactory factory = TransformerFactory.newInstance();
			factory.setAttribute("indent-number", 2);             
			Transformer transformer = factory.newTransformer();
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
			StreamSource source = new StreamSource(new StringReader(xml.replaceAll(">\\s+<", "><").trim()));
			StreamResult result = new StreamResult(new StringWriter());
			
			transformer.transform(source, result);
			
			return result.getWriter().toString();
		} catch (IllegalArgumentException | TransformerFactoryConfigurationError | TransformerException e) {
			throw new RuntimeException("Could not format xml", e);
		}
	}

}
