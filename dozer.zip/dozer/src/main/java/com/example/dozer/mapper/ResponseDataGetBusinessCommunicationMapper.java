package com.example.dozer.mapper;

import com.github.dozermapper.core.DozerBeanMapperBuilder;
import com.github.dozermapper.core.Mapper;

public class ResponseDataGetBusinessCommunicationMapper {
	
	public static bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.ResponseDataGetBusinessCommunication mapCreateToGetV2(bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.RequestDataCreateBusinessCommunication v2create) {
		Mapper mapper = DozerBeanMapperBuilder.create().withMappingFiles("create-to-get.xml").build();
		return mapper.map(v2create, bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.ResponseDataGetBusinessCommunication.class);
	}

}
