package com.example.dozer.mapper;

import com.github.dozermapper.core.DozerBeanMapperBuilder;
import com.github.dozermapper.core.Mapper;

public class RequestDataCreateBusinessCommunicationMapper {
	
	public static bc.web.api.capability.business.b170.cbu.services.businesscommunication.v3.RequestDataCreateBusinessCommunication mapV2toV3(bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.RequestDataCreateBusinessCommunication v2) {
		Mapper mapper = DozerBeanMapperBuilder.buildDefault();
		return mapper.map(v2, bc.web.api.capability.business.b170.cbu.services.businesscommunication.v3.RequestDataCreateBusinessCommunication.class);
	}

}
