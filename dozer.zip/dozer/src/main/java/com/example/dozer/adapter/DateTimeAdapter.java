package com.example.dozer.adapter;

import javax.xml.bind.annotation.adapters.XmlAdapter;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

public class DateTimeAdapter extends XmlAdapter<String, XMLGregorianCalendar> {

    @Override
    public String marshal(XMLGregorianCalendar c) throws Exception {
    	c.setMillisecond(c.getMillisecond()); // round fractional to milliseconds
        return c.toString();
    }
  
    @Override
    public XMLGregorianCalendar unmarshal(String s) throws Exception {         
    	XMLGregorianCalendar c = DatatypeFactory.newInstance().newXMLGregorianCalendar(s);
    	return c;
    }	
	
}
