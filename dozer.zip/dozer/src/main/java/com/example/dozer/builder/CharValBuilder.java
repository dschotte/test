package com.example.dozer.builder;

import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.BusinessCommunicationCharValType;

public class CharValBuilder {

	public static BusinessCommunicationCharValType build(String nm, String val) {
		BusinessCommunicationCharValType charVal = new BusinessCommunicationCharValType();
		charVal.setCharacteristicName(NameBuilder.defaultName(nm));
		charVal.setValue(NameBuilder.defaultName(val));
		return charVal;
	}

	public static BusinessCommunicationCharValType tplId(String appId, String val) {
		return build(appId + "_TEMPLATE_ID", val);
	}

	public static BusinessCommunicationCharValType tplNm(String appId, String val) {
		return build(appId + "_TEMPLATE_NM", val);
	}

	public static BusinessCommunicationCharValType tplDescr(String appId, String val) {
		return build(appId + "_TEMPLATE_DESCR", val);
	}

	public static BusinessCommunicationCharValType campaignId(String appId, String val) {
		return build(appId + "_CAMPAIGN_ID", val);
	}

	public static BusinessCommunicationCharValType campaignNm(String appId, String val) {
		return build(appId + "_CAMPAIGN_NM", val);
	}

	public static BusinessCommunicationCharValType svcNm(String appId, String val) {
		return build(appId + "_SERVICE_NM", val);
	}

	public static BusinessCommunicationCharValType bcTp(String val) {
		return build("businessCommunication.type", val);
	}	

}
