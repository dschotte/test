package com.example.dozer.builder;

import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.BusinessCommunicationRelationshipType;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.ChoiceBusinessInteractionIdentifierInCommunicationType;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.CustomerOrderIdentifierType;

public class RelationshipBuilder {

	public static BusinessCommunicationRelationshipType custOrderId(String id, String idCtx, String idScope) {
		BusinessCommunicationRelationshipType itemRs = new BusinessCommunicationRelationshipType();
		ChoiceBusinessInteractionIdentifierInCommunicationType choiceBusinessInteractionIdentifierInCommunication = new ChoiceBusinessInteractionIdentifierInCommunicationType();
		CustomerOrderIdentifierType customerOrderIdentifier = new CustomerOrderIdentifierType();
		customerOrderIdentifier.setId(id);
		customerOrderIdentifier.setIdContext(CodeValueBuilder.value(idCtx));
		customerOrderIdentifier.setIdScope(CodeValueBuilder.value(idScope));
		choiceBusinessInteractionIdentifierInCommunication.setCustomerOrderIdentifier(customerOrderIdentifier);
		itemRs.getBusinessInteractionIdentifiers().add(choiceBusinessInteractionIdentifierInCommunication);
		return itemRs;
	}	
	
}
