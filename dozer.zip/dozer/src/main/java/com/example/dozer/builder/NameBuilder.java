package com.example.dozer.builder;

import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.NameType;

public class NameBuilder {

	public static NameType defaultName(String val) {
		NameType name = new NameType();
		name.setDefaultName(val);
		return name;
	}

}
