package com.example.dozer.builder;

import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.BusinessCommunicationIdentifierType;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.BusinessCommunicationItemRelationshipType;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.CaseIdentifierType;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.ChoiceBusinessInteractionIdentifierInCommunicationType;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.IncidentIdentifierType;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.LeadIdentifierType;
import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.WorkOrderIdentifierType;

public class ItemRelationshipBuilder {

	public static BusinessCommunicationItemRelationshipType woId(String id, String idCtx, String idScope) {
		BusinessCommunicationItemRelationshipType itemRs = new BusinessCommunicationItemRelationshipType();
		ChoiceBusinessInteractionIdentifierInCommunicationType choiceBusinessInteractionIdentifierInCommunication = new ChoiceBusinessInteractionIdentifierInCommunicationType();
		WorkOrderIdentifierType workOrderIdentifier = new WorkOrderIdentifierType();
		workOrderIdentifier.setId(id);
		workOrderIdentifier.setIdContext(CodeValueBuilder.value(idCtx));
		workOrderIdentifier.setIdScope(CodeValueBuilder.value(idScope));
		choiceBusinessInteractionIdentifierInCommunication.setWorkOrderIdentifier(workOrderIdentifier);
		itemRs.getBusinessInteractionIdentifiers().add(choiceBusinessInteractionIdentifierInCommunication);
		return itemRs;
	}

	public static BusinessCommunicationItemRelationshipType commId(String id, String idCtx, String idScope) {
		BusinessCommunicationItemRelationshipType itemRs = new BusinessCommunicationItemRelationshipType();
		ChoiceBusinessInteractionIdentifierInCommunicationType choiceBusinessInteractionIdentifierInCommunication = new ChoiceBusinessInteractionIdentifierInCommunicationType();
		BusinessCommunicationIdentifierType businessCommunicationIdentifier = new BusinessCommunicationIdentifierType();
		businessCommunicationIdentifier.setId(id);
		businessCommunicationIdentifier.setIdContext(CodeValueBuilder.value(idCtx));
		businessCommunicationIdentifier.setIdScope(CodeValueBuilder.value(idScope));
		choiceBusinessInteractionIdentifierInCommunication.setBusinessCommunicationIdentifier(businessCommunicationIdentifier);
		itemRs.getBusinessInteractionIdentifiers().add(choiceBusinessInteractionIdentifierInCommunication);
		return itemRs;
	}

	public static BusinessCommunicationItemRelationshipType leadId(String id, String idCtx, String idScope) {
		BusinessCommunicationItemRelationshipType itemRs = new BusinessCommunicationItemRelationshipType();
		ChoiceBusinessInteractionIdentifierInCommunicationType choiceBusinessInteractionIdentifierInCommunication = new ChoiceBusinessInteractionIdentifierInCommunicationType();
		LeadIdentifierType leadIdentifier = new LeadIdentifierType();
		leadIdentifier.setId(id);
		leadIdentifier.setIdContext(CodeValueBuilder.value(idCtx));
		leadIdentifier.setIdScope(CodeValueBuilder.value(idScope));
		choiceBusinessInteractionIdentifierInCommunication.setLeadIdentifier(leadIdentifier);
		itemRs.getBusinessInteractionIdentifiers().add(choiceBusinessInteractionIdentifierInCommunication);
		return itemRs;
	}

	public static BusinessCommunicationItemRelationshipType caseId(String id, String idCtx, String idScope) {
		BusinessCommunicationItemRelationshipType itemRs = new BusinessCommunicationItemRelationshipType();
		ChoiceBusinessInteractionIdentifierInCommunicationType choiceBusinessInteractionIdentifierInCommunication = new ChoiceBusinessInteractionIdentifierInCommunicationType();
		CaseIdentifierType caseIdentifier = new CaseIdentifierType();
		caseIdentifier.setId(id);
		caseIdentifier.setIdContext(CodeValueBuilder.value(idCtx));
		caseIdentifier.setIdScope(CodeValueBuilder.value(idScope));
		choiceBusinessInteractionIdentifierInCommunication.setCaseIdentifier(caseIdentifier);
		itemRs.getBusinessInteractionIdentifiers().add(choiceBusinessInteractionIdentifierInCommunication);
		return itemRs;
	}

	public static BusinessCommunicationItemRelationshipType incidentId(String id, String idCtx, String idScope) {
		BusinessCommunicationItemRelationshipType itemRs = new BusinessCommunicationItemRelationshipType();
		ChoiceBusinessInteractionIdentifierInCommunicationType choiceBusinessInteractionIdentifierInCommunication = new ChoiceBusinessInteractionIdentifierInCommunicationType();
		IncidentIdentifierType incidentIdentifier = new IncidentIdentifierType();
		incidentIdentifier.setId(id);
		incidentIdentifier.setIdContext(CodeValueBuilder.value(idCtx));
		incidentIdentifier.setIdScope(CodeValueBuilder.value(idScope));
		choiceBusinessInteractionIdentifierInCommunication.setIncidentIdentifier(incidentIdentifier);
		itemRs.getBusinessInteractionIdentifiers().add(choiceBusinessInteractionIdentifierInCommunication);
		return itemRs;
	}	
	
}
