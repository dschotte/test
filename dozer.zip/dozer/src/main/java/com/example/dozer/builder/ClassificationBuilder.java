package com.example.dozer.builder;

import bc.web.api.capability.business.b170.cbu.objects.responsegetbusinesscommunication.v2.BusinessCommunicationItemClassificationType;

public class ClassificationBuilder {

	public static BusinessCommunicationItemClassificationType classification(String cdSystem, String val) {
		BusinessCommunicationItemClassificationType classification = new BusinessCommunicationItemClassificationType();
		classification.setClassification(CodeValueBuilder.codeValue(cdSystem, val));
		return classification;
	}

	public static BusinessCommunicationItemClassificationType ctDomainCd(String val) {
		return classification("ContactDomain", val);
	}

	public static BusinessCommunicationItemClassificationType productFamCd(String val) {
		return classification("ProductFamily", val);
	}

}
