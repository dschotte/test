package com.example.dozer.utils;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsonUtilsTests {
		
	@Test
	void shouldPreserveJson() throws IOException {
		Path path = Paths.get("src/test/resources/RequestDataUpdateBusinessCommunication.xml");	 
	    String xml2src = Files.readAllLines(path).stream().collect(Collectors.joining("\n"));
	    
	    bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.RequestDataUpdateBusinessCommunication v2 = XmlUtils.unmarshal(xml2src, bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.RequestDataUpdateBusinessCommunication.class);
		System.err.println(v2.getServiceData().getBusinessCommunication().getInteractionDuration().getStartTimeStamp().getValue()); // timezone
	    
		String json2 = JsonUtils.serialize(v2);
	    System.out.println(json2); // timezone
	    
	    bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.RequestDataUpdateBusinessCommunication v2back = JsonUtils.deserialize(json2, bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.RequestDataUpdateBusinessCommunication.class);
		System.err.println(v2back.getServiceData().getBusinessCommunication().getInteractionDuration().getStartTimeStamp().getValue()); // timezone

		String json2back = JsonUtils.serialize(v2back);
	    System.out.println(json2back); // timezone

		assertThat(json2back).isEqualTo(json2);
	}

	//@Test
	void shouldFormatJson() throws IOException {
		Path path = Paths.get("src/test/resources/RequestDataUpdateBusinessCommunication.xml");	 
	    String xml2src = Files.readAllLines(path).stream().collect(Collectors.joining("\n"));
	    
	    bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.RequestDataUpdateBusinessCommunication v2 = XmlUtils.unmarshal(xml2src, bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.RequestDataUpdateBusinessCommunication.class);
	    
		String json2 = JsonUtils.serialize(v2);
	    System.err.println(json2);
	    
	    String json2formatted = JsonUtils.formatJson(json2);
	    System.out.println(json2formatted);
	    
		assertThat(json2formatted).isNotEqualTo(json2);	    
	}
	
}
