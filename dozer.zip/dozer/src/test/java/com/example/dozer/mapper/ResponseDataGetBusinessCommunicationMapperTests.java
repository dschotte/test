package com.example.dozer.mapper;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.dozer.utils.XmlUtils;

@SpringBootTest
class ResponseDataGetBusinessCommunicationMapperTests {
		
	@Test
	void shouldMap() throws IOException {
		Path path = Paths.get("src/test/resources/RequestDataCreateBusinessCommunication.xml");	 
	    String xmlSrc = Files.readAllLines(path).stream().collect(Collectors.joining("\n"));
	    
	    bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.RequestDataCreateBusinessCommunication v2create = XmlUtils.unmarshal(xmlSrc, bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.RequestDataCreateBusinessCommunication.class);   
		String xml2create = XmlUtils.marshal(v2create, bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.RequestDataCreateBusinessCommunication.class);
		System.err.println(XmlUtils.formatXml(xml2create));
	    	    
	    bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.ResponseDataGetBusinessCommunication v2get = ResponseDataGetBusinessCommunicationMapper.mapCreateToGetV2(v2create);
		String xml2get = XmlUtils.marshal(v2get, bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.ResponseDataGetBusinessCommunication.class);
	    System.err.println(XmlUtils.formatXml(xml2get));
	    
		assertThat(xml2get).isEqualTo(xml2create.replaceAll("RequestDataCreateBusinessCommunication", "ResponseDataGetBusinessCommunication").replaceAll("requestcreatebusinesscommunication", "responsegetbusinesscommunication"));
	}	

}
