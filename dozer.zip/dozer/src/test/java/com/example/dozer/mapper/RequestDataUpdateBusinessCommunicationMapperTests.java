package com.example.dozer.mapper;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.dozer.utils.XmlUtils;

@SpringBootTest
class RequestDataUpdateBusinessCommunicationMapperTests {

	@Test
	void shouldMap() throws IOException {
		Path path = Paths.get("src/test/resources/RequestDataUpdateBusinessCommunication.xml");	 
	    String xmlSrc = Files.readAllLines(path).stream().collect(Collectors.joining("\n"));
	    
	    bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.RequestDataUpdateBusinessCommunication v2 = XmlUtils.unmarshal(xmlSrc, bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.RequestDataUpdateBusinessCommunication.class);
		System.err.println(v2.getServiceData().getBusinessCommunication().getInteractionDuration().getStartTimeStamp().getValue()); // timezone nanosec
	    
		String xml2 = XmlUtils.formatXml(XmlUtils.marshal(v2, bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.RequestDataUpdateBusinessCommunication.class));
	    System.out.println(xml2); // timezone millisec
	    	    
	    bc.web.api.capability.business.b170.cbu.services.businesscommunication.v3.RequestDataUpdateBusinessCommunication v3 = RequestDataUpdateBusinessCommunicationMapper.mapV2toV3(v2);
		System.err.println(v3.getServiceData().getBusinessCommunication().getInteractionDuration().getStartTimeStamp().getValue()); // timezone millisec

		String xml3 = XmlUtils.formatXml(XmlUtils.marshal(v3, bc.web.api.capability.business.b170.cbu.services.businesscommunication.v3.RequestDataUpdateBusinessCommunication.class));
	    System.out.println(xml3); // timezone millisec
	    
		assertThat(xml3).isEqualTo(xml2.replaceAll(" updateAction=\"modify\"", "").replaceAll("businesscommunication/v2", "businesscommunication/v3"));
	}	
	
}
