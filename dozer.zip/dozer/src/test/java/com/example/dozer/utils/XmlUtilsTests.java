package com.example.dozer.utils;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XmlUtilsTests {

	@Test
	void shouldPreserveXml() throws IOException {
		Path path = Paths.get("src/test/resources/RequestDataUpdateBusinessCommunication.xml");	 
	    String xml2src = Files.readAllLines(path).stream().collect(Collectors.joining("\n"));
	    
	    bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.RequestDataUpdateBusinessCommunication v2 = XmlUtils.unmarshal(xml2src, bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.RequestDataUpdateBusinessCommunication.class);
		System.err.println(v2.getServiceData().getBusinessCommunication().getInteractionDuration().getStartTimeStamp().getValue()); // timezone
	    
		String xml2 = XmlUtils.marshal(v2, bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.RequestDataUpdateBusinessCommunication.class);
	    System.out.println(xml2); // timezone
	    
	    bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.RequestDataUpdateBusinessCommunication v2back = XmlUtils.unmarshal(xml2, bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.RequestDataUpdateBusinessCommunication.class);
		System.err.println(v2back.getServiceData().getBusinessCommunication().getInteractionDuration().getStartTimeStamp().getValue()); // timezone

		String xml2back = XmlUtils.marshal(v2back, bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.RequestDataUpdateBusinessCommunication.class);
	    System.out.println(xml2back); // timezone

		assertThat(xml2back).isEqualTo(xml2);
	}	
	
	@Test
	void shouldFormatXml() throws IOException {
		Path path = Paths.get("src/test/resources/RequestDataUpdateBusinessCommunication.xml");	 
	    String xml2src = Files.readAllLines(path).stream().collect(Collectors.joining("\n"));
	    
	    bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.RequestDataUpdateBusinessCommunication v2 = XmlUtils.unmarshal(xml2src, bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.RequestDataUpdateBusinessCommunication.class);
	    
		String xml2 = XmlUtils.marshal(v2, bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.RequestDataUpdateBusinessCommunication.class);
	    System.err.println(xml2);
	    
	    String xml2formatted = XmlUtils.formatXml(xml2);
	    System.out.println(xml2formatted);
	    
		assertThat(xml2formatted).isNotEqualTo(xml2);	    
	}
		
}
