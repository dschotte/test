package com.example.dozer.mapper;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.dozer.utils.XmlUtils;

@SpringBootTest
class RequestDataCreateBusinessCommunicationMapperTests {
		
	@Test
	void shouldMap() throws IOException {
		Path path = Paths.get("src/test/resources/RequestDataCreateBusinessCommunication.xml");	 
	    String xmlSrc = Files.readAllLines(path).stream().collect(Collectors.joining("\n"));
	    
	    bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.RequestDataCreateBusinessCommunication v2 = XmlUtils.unmarshal(xmlSrc, bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.RequestDataCreateBusinessCommunication.class);   
		String xml2 = XmlUtils.marshal(v2, bc.web.api.capability.business.b170.cbu.services.businesscommunication.v2.RequestDataCreateBusinessCommunication.class);
	    System.err.println(xml2);
	    	    
	    bc.web.api.capability.business.b170.cbu.services.businesscommunication.v3.RequestDataCreateBusinessCommunication v3 = RequestDataCreateBusinessCommunicationMapper.mapV2toV3(v2);
		String xml3 = XmlUtils.marshal(v3, bc.web.api.capability.business.b170.cbu.services.businesscommunication.v3.RequestDataCreateBusinessCommunication.class);
	    System.err.println(xml3);
	    
		assertThat(xml3).isEqualTo(xml2.replaceAll("businesscommunication/v2", "businesscommunication/v3"));
	}	

}
