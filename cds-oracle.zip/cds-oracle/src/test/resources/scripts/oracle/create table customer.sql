DROP TABLE customer;

CREATE TABLE customer
(id RAW(16) PRIMARY KEY
,age NUMBER(3)
,name VARCHAR2(20)
,is_member VARCHAR2(1)
,order_seq NUMBER(10)
,fee NUMBER(11,2)
,remark CLOB
,json_doc BLOB
,xml_doc XMLTYPE
,created_on DATE
,creation_time DATE
,modified_at TIMESTAMP
,lnk_id RAW(16)
);

ALTER TABLE customer ADD CONSTRAINT cust_chk1 CHECK (is_member IN ('Y','N'));

ALTER TABLE customer ADD CONSTRAINT cust_chk2 CHECK (json_doc IS JSON) DISABLE;
