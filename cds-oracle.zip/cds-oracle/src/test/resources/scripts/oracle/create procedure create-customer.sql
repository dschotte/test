CREATE OR REPLACE PROCEDURE create_customer(p_id RAW, p_age NUMBER, p_name VARCHAR2, p_is_member VARCHAR2, p_order_seq NUMBER, p_fee NUMBER, p_remark CLOB, p_json_doc BLOB, p_xml_doc XMLTYPE, p_created_on DATE, p_creation_time DATE, p_modified_at TIMESTAMP, p_lnk_id RAW) IS
BEGIN
	INSERT INTO customer (id, age, name, is_member, order_seq, fee, remark, json_doc, xml_doc, created_on, creation_time, modified_at, lnk_id)
	VALUES (p_id, p_age, p_name, p_is_member, p_order_seq, p_fee, p_remark, p_json_doc, XMLTYPE(p_xml_doc), p_created_on, p_creation_time, p_modified_at, p_lnk_id);
END;
