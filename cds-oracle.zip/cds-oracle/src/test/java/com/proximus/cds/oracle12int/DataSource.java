package com.proximus.cds.oracle12int;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.zaxxer.hikari.HikariDataSource;

public class DataSource {
	
    private static HikariDataSource ds;
 
    static {
        ds = new HikariDataSource();
        ds.setJdbcUrl("jdbc:oracle:thin:@localhost:1521/orclpdb1.localdomain");
        ds.setUsername("scott");
        ds.setPassword("scott");
        ds.setAutoCommit(false);
    }
 
    private DataSource() {}
 
    public static Connection getConnection() throws SQLException {
        return ds.getConnection();
    }

	public static Connection getDirectConnection() throws SQLException {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/orclpdb1.localdomain", "scott", "scott");
			conn.setAutoCommit(false);
			return conn;
		} catch (ClassNotFoundException e) {
			throw new SQLException(e);
		}
	}

}
