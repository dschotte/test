package com.proximus.cds.oracle12int;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.UUID;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public class Customer {
	
	public UUID id;
	public int age;
	public String name;
	public boolean isMember;
	public long orderSeq;
	public double fee;
	public String remark;
	public String jsonDoc;
	public String xmlDoc;
	public LocalDate createdOn;
	public LocalTime creationTime;
	public LocalDateTime modifiedAt;
	public UUID linkedId;
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

}
