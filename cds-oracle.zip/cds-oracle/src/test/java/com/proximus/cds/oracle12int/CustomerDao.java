package com.proximus.cds.oracle12int;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

import org.apache.commons.codec.binary.StringUtils;
import org.apache.commons.lang3.BooleanUtils;

import com.proximus.cds.oracle12.JdbcUtils;
import com.proximus.cds.oracle12.ParameterType;
import com.proximus.cds.oracle12.RowMapper;
import com.proximus.cds.oracle12.SimpleCall;
import com.proximus.cds.oracle12.SimpleResult;

public class CustomerDao {

	private Connection conn;
	
	private class CustomerRowMapper implements RowMapper<Customer> {
		@Override public Customer mapRow(SimpleResult r) throws SQLException {
			Customer customer = new Customer();
			customer.id = r.getUUID("id");
			customer.age = r.getInt("age");
			customer.name = r.getString("name");
			customer.isMember = BooleanUtils.toBoolean(r.getString("is_member"), "Y", "N");
			customer.orderSeq = r.getLong("order_seq");
			customer.fee = r.getDouble("fee");
			customer.remark = r.getClobAsString("remark");
			customer.jsonDoc = StringUtils.newStringUtf8(r.getBytes("json_doc"));
			customer.xmlDoc = r.getXMLTypeAsString("xml_doc");
			customer.createdOn = r.getLocalDate("created_on");
			customer.creationTime = r.getLocalTime("creation_time");
			customer.modifiedAt = r.getLocalDateTime("modified_at");
			customer.linkedId = r.getUUID("lnk_id");
			return customer;
		}
	}
	
	public CustomerDao(Connection conn) {
		super();
		this.conn = conn;
	}

	public List<Customer> findCustomers() throws SQLException {
		SimpleCall c = null;
		try {
			c = new SimpleCall(conn, "{ :result = call find_customers }");
			c.registerOutParameter("result", ParameterType.CURSOR);
			
			c.execute();
			
			return c.getCursor("result").toRows(new CustomerRowMapper());
		} finally {
			JdbcUtils.close(c);
		}
	}

	public void createCustomer(Customer customer) throws SQLException {
		SimpleCall c = null;
		try {
			c = new SimpleCall(conn, "{ call create_customer(:id, :age, :name, :is_member, :order_seq, :fee, :remark, :json_doc, :xml_doc, :created_on, :creation_time, :modified_at, :lnk_id) }");
			c.setUUID("id", customer.id);
			c.setInt("age", customer.age);
			c.setString("name", customer.name);
			c.setString("is_member", BooleanUtils.toString(customer.isMember, "Y", "N"));
			c.setLong("order_seq", customer.orderSeq);
			c.setDouble("fee", customer.fee);
			c.setString("remark", customer.remark);
			c.setBytes("json_doc", StringUtils.getBytesUtf8(customer.jsonDoc));
			c.setXMLType("xml_doc", customer.xmlDoc);
			c.setLocalDate("created_on", customer.createdOn);
			c.setLocalTime("creation_time", customer.creationTime);
			c.setLocalDateTime("modified_at", customer.modifiedAt);
			c.setUUID("lnk_id", customer.linkedId);
			
			c.execute();
		} finally {
			JdbcUtils.close(c);
		}		
	}

	public Customer getCustomer(UUID id) throws SQLException {
		SimpleCall c = null;
		try {
			c = new SimpleCall(conn, "{ :result = call get_customer(:id) }");
			c.setUUID("id", id);
			c.registerOutParameter("result", ParameterType.CURSOR);
			
			c.execute();
			
			return c.getCursor("result").toRow(new CustomerRowMapper());
		} finally {
			JdbcUtils.close(c);
		}
	}
	
}
