package com.proximus.cds.oracle12;

import java.sql.Blob;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLXML;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class JdbcUtils {
	
    private static final Logger logger = LoggerFactory.getLogger(JdbcUtils.class);
 	
	public static void close(Connection conn) {
		try {
			if (conn != null) {
				rollback(conn);
				conn.close();				
			}
		} catch (SQLException e) {
			logger.error("Could not close connection", e);
		}
	}

    public static void close(SimpleCall c) {
        try {
            if (c != null) {
            	c.close();
            }
        } catch (SQLException e) {
			logger.error("Could not close", e);
        }
    }    

    protected static void close(SimpleResult r) {
        try {
            if (r != null) {
            	r.close();
            }
        } catch (SQLException e) {
			logger.error("Could not close", e);
        }
    }

    public static void rollback(Connection conn) {
		try {
			if (conn != null) {
				conn.rollback();				
			}
		} catch (SQLException e) {
			logger.error("Could not undo changes and release locks held by connection", e);
		}
	}

	protected static void free(Blob blob) {
		try {
			if (blob != null) {
				blob.free();
			}
		} catch (SQLException e) {
			logger.error("Could not free object", e);
		}
	}    
 
	protected static void free(Clob clob) {
		try {
			if (clob != null) {
				clob.free();
			}
		} catch (SQLException e) {
			logger.error("Could not free object", e);
		}
	}    

	protected static void free(SQLXML XML) {
		try {
			if (XML != null) {
				XML.free();
			}
		} catch (SQLException e) {
			logger.error("Could not free object", e);
		}
	}    
    
}
