package com.proximus.cds.oracle12;

import java.sql.SQLException;

public interface RowMapper<T> {

	T mapRow(SimpleResult rs) throws SQLException;
	
}
