package com.proximus.cds.oracle12;

import java.sql.Blob;
import java.sql.Clob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import oracle.xdb.XMLType;

public class SimpleResult {
	
	private ResultSet rs;

	public SimpleResult(ResultSet rs) {
		super();
		this.rs = rs;
	}
	
	public boolean next() throws SQLException {
		return rs.next();
	}
	
	public byte[] getBlobAsBytes(String columnLabel) throws SQLException {
	   	Blob blob = null;
		try {
			blob = rs.getBlob(columnLabel);
			if (rs.wasNull()) {
				return null;
			}
			return blob.getBytes(1, (int) blob.length());
		} finally {
			JdbcUtils.free(blob);
		}		
	}
	
	public byte[] getBytes(String columnLabel) throws SQLException {
		byte[] bytes = rs.getBytes(columnLabel);
		if (rs.wasNull()) {
			return null;
		}
		return bytes;
	}

	public String getClobAsString(String columnLabel) throws SQLException {
		Clob clob = null;
		try {
			clob = rs.getClob(columnLabel);			
			if (rs.wasNull()) {
				return null;
			}
			return clob.getSubString(1, (int) clob.length());
		} finally {
			JdbcUtils.free(clob);
		}		
	}	
	
	public double getDouble(String columnLabel) throws SQLException {
		return rs.getDouble(columnLabel);
	}

	public int getInt(String columnLabel) throws SQLException {
		return rs.getInt(columnLabel);
	}

	public LocalDate getLocalDate(String columnLabel) throws SQLException {
		java.sql.Date date = rs.getDate(columnLabel);
		if (rs.wasNull()) {
			return null;
		}
		return date.toLocalDate();
	}
	
	public LocalDateTime getLocalDateTime(String columnLabel) throws SQLException {
		java.sql.Timestamp timestamp = rs.getTimestamp(columnLabel);
		if (rs.wasNull()) {
			return null;
		}
		return timestamp.toLocalDateTime();
	}	

	public LocalTime getLocalTime(String columnLabel) throws SQLException {
		java.sql.Time time = rs.getTime(columnLabel);
		if (rs.wasNull()) {
			return null;
		}
		return time.toLocalTime();
	}

	public long getLong(String columnLabel) throws SQLException {
		return rs.getLong(columnLabel);
	}	

	public String getString(String columnLabel) throws SQLException {
		return rs.getString(columnLabel);
	}
	
	public UUID getUUID(String columLabel) throws SQLException {
		byte[] bytes = rs.getBytes(columLabel);
		if (rs.wasNull()) {
			return null;
		}
		return UUIDUtils.toUUID(bytes);
	}

	public String getXMLTypeAsString(String columnLabel) throws SQLException {
		XMLType xml = null;	
		try {
			xml = (XMLType) rs.getObject(columnLabel); 
			if (rs.wasNull()) {
				return null;
			}
			return xml.getString();
		} finally {
			JdbcUtils.free(xml);
		}
	}
	
	public <T> T toRow(RowMapper<T> rowMapper) throws SQLException {
        T row = null;
        try {
            if (rs.next()) {
                row = rowMapper.mapRow(this);
                if (rs.next()) throw new SQLException("Too many rows");
            }
        } finally {
            rs.close();
        }
        return row;
    }    	

    public <T> List<T> toRows(RowMapper<T> rowMapper) throws SQLException {
        List<T> rows = new ArrayList<T>();
        try {
            while (rs.next()) {
                rows.add(rowMapper.mapRow(this));
            }
        } finally {
            rs.close();
        }
        return rows;
    }
	
	public void close() throws SQLException {
		rs.close();
	}

}
